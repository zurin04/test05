import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  ChevronLeft, 
  ChevronRight, 
  X, 
  CheckCircle, 
  Play,
  Users,
  MessageSquare,
  Heart,
  Bookmark,
  Plus,
  Search,
  Bell,
  Settings,
  FlaskConical
} from "lucide-react";

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  target?: string;
  action?: string;
  completed?: boolean;
}

interface OnboardingTourProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

const onboardingSteps: OnboardingStep[] = [
  {
    id: "welcome",
    title: "Welcome to CryptoHub!",
    description: "Your gateway to the latest testnets, airdrops, and crypto opportunities. Let's get you started!",
    icon: <FlaskConical className="w-6 h-6" />,
  },
  {
    id: "browse-posts",
    title: "Discover Content",
    description: "Browse posts about testnets, node setups, social tasks, and airdrops. Use categories and search to find what interests you.",
    icon: <Search className="w-6 h-6" />,
    target: ".search-bar",
    action: "Try searching for 'testnet'"
  },
  {
    id: "engage",
    title: "Engage with Community",
    description: "Like posts you find helpful, comment with your thoughts, and save content for later reference.",
    icon: <Heart className="w-6 h-6" />,
    target: ".post-card",
    action: "Like a post to show appreciation"
  },
  {
    id: "notifications",
    title: "Stay Updated",
    description: "Get notified when others interact with your content or when new opportunities are posted.",
    icon: <Bell className="w-6 h-6" />,
    target: ".notification-center",
    action: "Click the bell icon to see notifications"
  },
  {
    id: "follow-users",
    title: "Follow Contributors",
    description: "Follow other users to see their latest posts and discoveries in your feed.",
    icon: <Users className="w-6 h-6" />,
    target: ".user-profile",
    action: "Visit a user's profile and follow them"
  },
  {
    id: "profile",
    title: "Complete Your Profile",
    description: "Add your information, connect your wallet, and let others know about your crypto interests.",
    icon: <Settings className="w-6 h-6" />,
    target: ".user-menu",
    action: "Go to Settings to update your profile"
  },
];

export default function OnboardingTour({ isOpen, onClose, onComplete }: OnboardingTourProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);

  const progress = ((currentStep + 1) / onboardingSteps.length) * 100;
  const step = onboardingSteps[currentStep];

  useEffect(() => {
    // Check for completed onboarding steps in localStorage
    const saved = localStorage.getItem('onboarding-completed-steps');
    if (saved) {
      setCompletedSteps(JSON.parse(saved));
    }
  }, []);

  const markStepCompleted = (stepId: string) => {
    if (!completedSteps.includes(stepId)) {
      const updated = [...completedSteps, stepId];
      setCompletedSteps(updated);
      localStorage.setItem('onboarding-completed-steps', JSON.stringify(updated));
    }
  };

  const nextStep = () => {
    markStepCompleted(step.id);
    if (currentStep < onboardingSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const goToStep = (stepIndex: number) => {
    setCurrentStep(stepIndex);
  };

  const handleComplete = () => {
    localStorage.setItem('onboarding-completed', 'true');
    onComplete();
    onClose();
  };

  const skipTour = () => {
    localStorage.setItem('onboarding-skipped', 'true');
    onClose();
  };

  const startInteractiveTour = () => {
    setIsPlaying(true);
    // This would integrate with a library like Shepherd.js or Driver.js for interactive highlighting
    console.log('Starting interactive tour...');
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center space-x-2">
              <span>Getting Started</span>
              <Badge variant="outline">
                Step {currentStep + 1} of {onboardingSteps.length}
              </Badge>
            </DialogTitle>
            <Button variant="ghost" size="sm" onClick={skipTour}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <Progress value={progress} className="mt-2" />
        </DialogHeader>

        <div className="space-y-6">
          {/* Current Step */}
          <Card className="border-2 border-primary">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  {step.icon}
                </div>
                <span>{step.title}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">{step.description}</p>
              
              {step.action && (
                <Alert>
                  <Play className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Try it:</strong> {step.action}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* Step Overview */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {onboardingSteps.map((stepItem, index) => (
              <Card 
                key={stepItem.id}
                className={`cursor-pointer transition-all ${
                  index === currentStep 
                    ? 'border-primary bg-primary/5' 
                    : completedSteps.includes(stepItem.id)
                    ? 'border-green-500 bg-green-50 dark:bg-green-950/20'
                    : 'hover:border-muted-foreground'
                }`}
                onClick={() => goToStep(index)}
              >
                <CardContent className="p-3">
                  <div className="flex items-center space-x-2">
                    <div className={`p-1.5 rounded ${
                      index === currentStep 
                        ? 'bg-primary text-primary-foreground' 
                        : completedSteps.includes(stepItem.id)
                        ? 'bg-green-500 text-white'
                        : 'bg-muted'
                    }`}>
                      {completedSteps.includes(stepItem.id) ? (
                        <CheckCircle className="w-3 h-3" />
                      ) : (
                        <div className="w-3 h-3 flex items-center justify-center text-xs font-bold">
                          {index + 1}
                        </div>
                      )}
                    </div>
                    <span className="text-sm font-medium truncate">{stepItem.title}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Interactive Tour Option */}
          {!isPlaying && step.target && (
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Want a guided tour?</h4>
                    <p className="text-sm text-muted-foreground">
                      We'll highlight the relevant parts of the interface as you go.
                    </p>
                  </div>
                  <Button onClick={startInteractiveTour} className="ml-4">
                    <Play className="w-4 h-4 mr-2" />
                    Start Tour
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Key Features Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">What You Can Do</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-3">
                  <FlaskConical className="w-5 h-5 text-blue-500" />
                  <div>
                    <p className="font-medium">Discover Testnets</p>
                    <p className="text-xs text-muted-foreground">Latest testing opportunities</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <MessageSquare className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="font-medium">Share Knowledge</p>
                    <p className="text-xs text-muted-foreground">Help the community grow</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Users className="w-5 h-5 text-purple-500" />
                  <div>
                    <p className="font-medium">Connect</p>
                    <p className="text-xs text-muted-foreground">Follow crypto enthusiasts</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Bookmark className="w-5 h-5 text-orange-500" />
                  <div>
                    <p className="font-medium">Save Content</p>
                    <p className="text-xs text-muted-foreground">Build your library</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <Button 
              variant="outline" 
              onClick={prevStep}
              disabled={currentStep === 0}
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Previous
            </Button>
            
            <div className="flex space-x-2">
              <Button variant="ghost" onClick={skipTour}>
                Skip Tour
              </Button>
              
              <Button onClick={nextStep}>
                {currentStep === onboardingSteps.length - 1 ? (
                  <>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Complete
                  </>
                ) : (
                  <>
                    Next
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Hook to manage onboarding state
export function useOnboarding() {
  const [shouldShowOnboarding, setShouldShowOnboarding] = useState(false);

  useEffect(() => {
    const completed = localStorage.getItem('onboarding-completed');
    const skipped = localStorage.getItem('onboarding-skipped');
    
    if (!completed && !skipped) {
      // Show onboarding after a short delay for new users
      const timer = setTimeout(() => {
        setShouldShowOnboarding(true);
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, []);

  const startOnboarding = () => {
    setShouldShowOnboarding(true);
  };

  const closeOnboarding = () => {
    setShouldShowOnboarding(false);
  };

  const completeOnboarding = () => {
    localStorage.setItem('onboarding-completed', 'true');
    setShouldShowOnboarding(false);
  };

  return {
    shouldShowOnboarding,
    startOnboarding,
    closeOnboarding,
    completeOnboarding,
  };
}
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Users, Settings, Shield, Crown, User as UserIcon } from "lucide-react";

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  walletAddress?: string;
  isActive: boolean;
  createdAt: string;
}

interface SiteSettings {
  site_name: string;
  site_logo: string;
  site_description: string;
  twitter_url: string;
  discord_url: string;
  telegram_url: string;
  github_url: string;
  allow_user_registration: string;
  require_email_verification: string;
  enable_web3_auth: string;
}

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [newRole, setNewRole] = useState<string>("");
  const [settings, setSettings] = useState<SiteSettings>({
    site_name: "",
    site_logo: "",
    site_description: "",
    twitter_url: "",
    discord_url: "",
    telegram_url: "",
    github_url: "",
    allow_user_registration: "true",
    require_email_verification: "false",
    enable_web3_auth: "true",
  });

  // Check if user is admin
  useEffect(() => {
    if (!isAuthenticated || user?.role !== "admin") {
      toast({
        title: "Unauthorized",
        description: "You need admin access to view this page.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 2000);
    }
  }, [isAuthenticated, user, toast]);

  // Fetch users
  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ["/api/admin/users"],
    enabled: isAuthenticated && user?.role === "admin",
    retry: false,
  });

  // Fetch site settings
  const { data: siteSettings, isLoading: settingsLoading } = useQuery({
    queryKey: ["/api/settings"],
    enabled: isAuthenticated && user?.role === "admin",
    retry: false,
  });

  // Update settings state when data loads
  useEffect(() => {
    if (siteSettings) {
      setSettings(prev => ({ ...prev, ...siteSettings }));
    }
  }, [siteSettings]);

  // Update user role mutation
  const updateRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: string }) => {
      return await apiRequest(`/api/admin/users/${userId}/role`, {
        method: "PATCH",
        body: JSON.stringify({ role }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Role updated",
        description: "User role has been updated successfully.",
      });
      setSelectedUserId("");
      setNewRole("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/auth";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update user role.",
        variant: "destructive",
      });
    },
  });

  // Update site settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (updatedSettings: Partial<SiteSettings>) => {
      return await apiRequest("/api/admin/settings", {
        method: "PATCH",
        body: JSON.stringify(updatedSettings),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Settings updated",
        description: "Site settings have been updated successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/auth";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update settings.",
        variant: "destructive",
      });
    },
  });

  const handleUpdateRole = () => {
    if (!selectedUserId || !newRole) {
      toast({
        title: "Error",
        description: "Please select a user and role.",
        variant: "destructive",
      });
      return;
    }

    updateRoleMutation.mutate({ userId: selectedUserId, role: newRole });
  };

  const handleSaveSettings = () => {
    updateSettingsMutation.mutate(settings);
  };

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case "admin":
        return "destructive";
      case "creator":
        return "default";
      default:
        return "secondary";
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case "admin":
        return <Shield className="w-4 h-4" />;
      case "creator":
        return <Crown className="w-4 h-4" />;
      default:
        return <UserIcon className="w-4 h-4" />;
    }
  };

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="p-6">
            <p>Checking permissions...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center space-x-4">
        <Shield className="w-8 h-8 text-red-500" />
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage users and site settings</p>
        </div>
      </div>

      <Tabs defaultValue="users" className="space-y-6">
        <TabsList>
          <TabsTrigger value="users" className="flex items-center space-x-2">
            <Users className="w-4 h-4" />
            <span>User Management</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center space-x-2">
            <Settings className="w-4 h-4" />
            <span>Site Settings</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>
                Manage user roles and permissions. Admins can create posts and manage the site. 
                Creators can create posts. Regular users can view, like, and comment.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {usersLoading ? (
                <p>Loading users...</p>
              ) : (
                <div className="space-y-4">
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>User</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Wallet</TableHead>
                          <TableHead>Role</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Joined</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {users.map((user: User) => (
                          <TableRow key={user.id}>
                            <TableCell>
                              <div className="font-medium">
                                {user.firstName} {user.lastName}
                              </div>
                            </TableCell>
                            <TableCell>{user.email || "N/A"}</TableCell>
                            <TableCell>
                              {user.walletAddress ? (
                                <code className="text-xs">
                                  {user.walletAddress.slice(0, 6)}...{user.walletAddress.slice(-4)}
                                </code>
                              ) : (
                                "N/A"
                              )}
                            </TableCell>
                            <TableCell>
                              <Badge variant={getRoleBadgeVariant(user.role)} className="flex items-center space-x-1 w-fit">
                                {getRoleIcon(user.role)}
                                <span className="capitalize">{user.role}</span>
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant={user.isActive ? "default" : "secondary"}>
                                {user.isActive ? "Active" : "Inactive"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {new Date(user.createdAt).toLocaleDateString()}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  <Card>
                    <CardHeader>
                      <CardTitle>Update User Role</CardTitle>
                      <CardDescription>
                        Promote users to creator or admin roles
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <Label htmlFor="user-select">Select User</Label>
                          <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                            <SelectTrigger>
                              <SelectValue placeholder="Choose user" />
                            </SelectTrigger>
                            <SelectContent>
                              {users.map((user: User) => (
                                <SelectItem key={user.id} value={user.id}>
                                  {user.firstName} {user.lastName} ({user.email || user.walletAddress?.slice(0, 8)})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label htmlFor="role-select">New Role</Label>
                          <Select value={newRole} onValueChange={setNewRole}>
                            <SelectTrigger>
                              <SelectValue placeholder="Choose role" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="user">User</SelectItem>
                              <SelectItem value="creator">Creator</SelectItem>
                              <SelectItem value="admin">Admin</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="flex items-end">
                          <Button 
                            onClick={handleUpdateRole}
                            disabled={updateRoleMutation.isPending || !selectedUserId || !newRole}
                            className="w-full"
                          >
                            {updateRoleMutation.isPending ? "Updating..." : "Update Role"}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Site Settings</CardTitle>
              <CardDescription>
                Configure your CryptoHub instance
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {settingsLoading ? (
                <p>Loading settings...</p>
              ) : (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="site_name">Site Name</Label>
                        <Input
                          id="site_name"
                          value={settings.site_name}
                          onChange={(e) => setSettings(prev => ({ ...prev, site_name: e.target.value }))}
                          placeholder="CryptoHub"
                        />
                      </div>

                      <div>
                        <Label htmlFor="site_logo">Site Logo URL</Label>
                        <Input
                          id="site_logo"
                          value={settings.site_logo}
                          onChange={(e) => setSettings(prev => ({ ...prev, site_logo: e.target.value }))}
                          placeholder="https://example.com/logo.png"
                        />
                      </div>

                      <div>
                        <Label htmlFor="site_description">Site Description</Label>
                        <Input
                          id="site_description"
                          value={settings.site_description}
                          onChange={(e) => setSettings(prev => ({ ...prev, site_description: e.target.value }))}
                          placeholder="Community platform for crypto enthusiasts"
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="twitter_url">Twitter/X URL</Label>
                        <Input
                          id="twitter_url"
                          value={settings.twitter_url}
                          onChange={(e) => setSettings(prev => ({ ...prev, twitter_url: e.target.value }))}
                          placeholder="https://twitter.com/yourhandle"
                        />
                      </div>

                      <div>
                        <Label htmlFor="discord_url">Discord URL</Label>
                        <Input
                          id="discord_url"
                          value={settings.discord_url}
                          onChange={(e) => setSettings(prev => ({ ...prev, discord_url: e.target.value }))}
                          placeholder="https://discord.gg/yourinvite"
                        />
                      </div>

                      <div>
                        <Label htmlFor="telegram_url">Telegram URL</Label>
                        <Input
                          id="telegram_url"
                          value={settings.telegram_url}
                          onChange={(e) => setSettings(prev => ({ ...prev, telegram_url: e.target.value }))}
                          placeholder="https://t.me/yourchannel"
                        />
                      </div>

                      <div>
                        <Label htmlFor="github_url">GitHub URL</Label>
                        <Input
                          id="github_url"
                          value={settings.github_url}
                          onChange={(e) => setSettings(prev => ({ ...prev, github_url: e.target.value }))}
                          placeholder="https://github.com/yourrepo"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="allow_user_registration">Allow User Registration</Label>
                      <Select 
                        value={settings.allow_user_registration} 
                        onValueChange={(value) => setSettings(prev => ({ ...prev, allow_user_registration: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="true">Enabled</SelectItem>
                          <SelectItem value="false">Disabled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="require_email_verification">Require Email Verification</Label>
                      <Select 
                        value={settings.require_email_verification} 
                        onValueChange={(value) => setSettings(prev => ({ ...prev, require_email_verification: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="true">Enabled</SelectItem>
                          <SelectItem value="false">Disabled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="enable_web3_auth">Enable Web3 Authentication</Label>
                      <Select 
                        value={settings.enable_web3_auth} 
                        onValueChange={(value) => setSettings(prev => ({ ...prev, enable_web3_auth: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="true">Enabled</SelectItem>
                          <SelectItem value="false">Disabled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button 
                    onClick={handleSaveSettings}
                    disabled={updateSettingsMutation.isPending}
                    className="w-full md:w-auto"
                  >
                    {updateSettingsMutation.isPending ? "Saving..." : "Save Settings"}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
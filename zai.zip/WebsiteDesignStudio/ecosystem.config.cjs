module.exports = {
  apps: [{
    name: 'cryptohub',
    script: 'dist/index.js',
    cwd: '/var/www/cryptohub',
    instances: 1,
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: process.env.DATABASE_URL || 'postgresql://cryptohub_user:password@localhost:5432/cryptohub_db',
      SESSION_SECRET: process.env.SESSION_SECRET || 'your-session-secret',
      PGHOST: 'localhost',
      PGPORT: '5432',
      PGUSER: 'cryptohub_user',
      PGPASSWORD: process.env.PGPASSWORD || 'password',
      PGDATABASE: 'cryptohub_db',
      REPL_ID: 'cryptohub-production',
      REPLIT_DOMAINS: 'localhost'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true,
    max_memory_restart: '1G',
    node_args: '--max-old-space-size=1024',
    restart_delay: 4000,
    max_restarts: 10,
    min_uptime: '10s',
    kill_timeout: 5000,
    wait_ready: true,
    listen_timeout: 10000,
    autorestart: true,
    watch: false
  }]
};
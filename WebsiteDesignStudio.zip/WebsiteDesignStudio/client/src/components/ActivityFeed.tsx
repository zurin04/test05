import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Activity, 
  Heart, 
  MessageSquare, 
  UserPlus, 
  FileText,
  TrendingUp,
  Clock,
  Users
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";

interface ActivityItem {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'post' | 'join';
  user: {
    id: string;
    firstName: string;
    lastName?: string;
    profileImage?: string;
  };
  target?: {
    id: string;
    title?: string;
    type: 'post' | 'user';
  };
  content?: string;
  createdAt: string;
}

interface ActivityFeedProps {
  variant?: 'full' | 'compact';
  userId?: string; // For user-specific activity
  limit?: number;
}

const getActivityIcon = (type: string) => {
  switch (type) {
    case 'like':
      return <Heart className="w-4 h-4 text-red-500" />;
    case 'comment':
      return <MessageSquare className="w-4 h-4 text-blue-500" />;
    case 'follow':
      return <UserPlus className="w-4 h-4 text-green-500" />;
    case 'post':
      return <FileText className="w-4 h-4 text-purple-500" />;
    case 'join':
      return <Users className="w-4 h-4 text-orange-500" />;
    default:
      return <Activity className="w-4 h-4" />;
  }
};

const getActivityMessage = (activity: ActivityItem) => {
  const userName = `${activity.user.firstName} ${activity.user.lastName || ''}`.trim();
  
  switch (activity.type) {
    case 'like':
      return `${userName} liked a post`;
    case 'comment':
      return `${userName} commented on a post`;
    case 'follow':
      return `${userName} followed someone`;
    case 'post':
      return `${userName} created a new post`;
    case 'join':
      return `${userName} joined CryptoHub`;
    default:
      return `${userName} was active`;
  }
};

export default function ActivityFeed({ 
  variant = 'full', 
  userId, 
  limit = 20 
}: ActivityFeedProps) {
  const [isLive, setIsLive] = useState(true);

  const { data: activities = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/activity', userId, limit],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (userId) params.append('userId', userId);
      params.append('limit', limit.toString());
      
      const response = await fetch(`/api/activity?${params.toString()}`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        if (response.status === 401) return [];
        throw new Error('Failed to fetch activity');
      }
      
      return response.json() as Promise<ActivityItem[]>;
    },
    refetchInterval: isLive ? 10000 : false, // Refetch every 10 seconds when live
  });

  const toggleLiveUpdates = () => {
    setIsLive(!isLive);
    if (!isLive) {
      refetch();
    }
  };

  if (variant === 'compact') {
    return (
      <Card className="w-full">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center space-x-2">
              <Activity className="w-5 h-5" />
              <span>Recent Activity</span>
            </CardTitle>
            <Button
              variant="outline"
              size="sm"
              onClick={toggleLiveUpdates}
              className={isLive ? 'border-green-500 text-green-600' : ''}
            >
              <div className={`w-2 h-2 rounded-full mr-2 ${isLive ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
              {isLive ? 'Live' : 'Paused'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-64">
            <div className="space-y-3">
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center space-x-3 animate-pulse">
                    <div className="w-8 h-8 bg-muted rounded-full" />
                    <div className="flex-1">
                      <div className="h-3 bg-muted rounded w-3/4 mb-1" />
                      <div className="h-2 bg-muted rounded w-1/2" />
                    </div>
                  </div>
                ))
              ) : activities.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>No recent activity</p>
                </div>
              ) : (
                activities.slice(0, 10).map((activity) => (
                  <div key={activity.id} className="flex items-center space-x-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={activity.user.profileImage} />
                      <AvatarFallback>
                        {activity.user.firstName[0]}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        {getActivityIcon(activity.type)}
                        <p className="text-sm truncate">
                          {getActivityMessage(activity)}
                        </p>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center space-x-2">
          <Activity className="w-6 h-6" />
          <span>Activity Feed</span>
        </h2>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={toggleLiveUpdates}
            className={isLive ? 'border-green-500 text-green-600' : ''}
          >
            <div className={`w-2 h-2 rounded-full mr-2 ${isLive ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
            {isLive ? 'Live Updates' : 'Updates Paused'}
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <ScrollArea className="h-96">
            <div className="divide-y">
              {isLoading ? (
                Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="p-4 animate-pulse">
                    <div className="flex items-start space-x-3">
                      <div className="w-10 h-10 bg-muted rounded-full" />
                      <div className="flex-1">
                        <div className="h-4 bg-muted rounded w-3/4 mb-2" />
                        <div className="h-3 bg-muted rounded w-1/2 mb-1" />
                        <div className="h-2 bg-muted rounded w-1/4" />
                      </div>
                    </div>
                  </div>
                ))
              ) : activities.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground">
                  <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <h3 className="font-medium mb-2">No activity yet</h3>
                  <p className="text-sm">
                    When users interact with posts and follow each other, their activity will appear here.
                  </p>
                </div>
              ) : (
                activities.map((activity) => (
                  <div key={activity.id} className="p-4 hover:bg-muted/50 transition-colors">
                    <div className="flex items-start space-x-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={activity.user.profileImage} />
                        <AvatarFallback>
                          {activity.user.firstName[0]}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          {getActivityIcon(activity.type)}
                          <p className="font-medium">
                            {getActivityMessage(activity)}
                          </p>
                        </div>
                        
                        {activity.target && (
                          <div className="mb-2">
                            {activity.target.type === 'post' && (
                              <Link href={`/?postId=${activity.target.id}`}>
                                <p className="text-sm text-blue-600 hover:underline cursor-pointer">
                                  "{activity.target.title}"
                                </p>
                              </Link>
                            )}
                            {activity.target.type === 'user' && (
                              <Link href={`/profile/${activity.target.id}`}>
                                <p className="text-sm text-blue-600 hover:underline cursor-pointer">
                                  View profile
                                </p>
                              </Link>
                            )}
                          </div>
                        )}
                        
                        {activity.content && (
                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                            {activity.content}
                          </p>
                        )}
                        
                        <div className="flex items-center justify-between">
                          <p className="text-xs text-muted-foreground">
                            {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })}
                          </p>
                          
                          {activity.type === 'post' && (
                            <Badge variant="secondary" className="text-xs">
                              New Post
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
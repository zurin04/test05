import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  User, 
  Settings, 
  BookmarkMinus,
  ExternalLink,
  Loader2,
  Heart,
  MessageCircle,
  Share2
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { User as UserType, PostWithDetails } from "@shared/schema";

interface UserDashboardProps {
  profileUser: UserType;
  currentUser: UserType;
  isOwnProfile: boolean;
}

const categoryStyles = {
  testnets: { bg: 'bg-crypto-blue', text: 'text-white', emoji: '🧪' },
  'node-setup': { bg: 'bg-crypto-cyan', text: 'text-white', emoji: '🖥️' },
  'social-tasks': { bg: 'bg-crypto-emerald', text: 'text-white', emoji: '📱' },
  airdrops: { bg: 'bg-crypto-purple', text: 'text-white', emoji: '🎁' },
};

export default function UserDashboard({ profileUser, currentUser, isOwnProfile }: UserDashboardProps) {
  const [activeTab, setActiveTab] = useState("posts");
  const [savedPostsSort, setSavedPostsSort] = useState("recent");
  const { toast } = useToast();

  // Fetch user stats
  const { data: userStats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/users', profileUser.id, 'stats'],
    queryFn: async () => {
      const response = await fetch(`/api/users/${profileUser.id}/stats`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    retry: false,
  });

  // Fetch saved posts (only for own profile)
  const { data: savedPosts = [], isLoading: savedPostsLoading, refetch: refetchSavedPosts } = useQuery({
    queryKey: ['/api/users', profileUser.id, 'saved-posts', savedPostsSort],
    queryFn: async () => {
      const response = await fetch(`/api/users/${profileUser.id}/saved-posts?sortBy=${savedPostsSort}`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('401: Unauthorized');
        }
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json() as Promise<PostWithDetails[]>;
    },
    enabled: isOwnProfile && activeTab === "saved",
    retry: false,
    meta: {
      onError: (error: Error) => {
        if (isUnauthorizedError(error)) {
          toast({
            title: "Unauthorized",
            description: "You are logged out. Logging in again...",
            variant: "destructive",
          });
          setTimeout(() => {
            window.location.href = "/api/login";
          }, 500);
        }
      }
    }
  });

  // Fetch user's posts
  const { data: userPosts = [], isLoading: userPostsLoading } = useQuery({
    queryKey: ['/api/posts', { userId: profileUser.id }],
    queryFn: async () => {
      const response = await fetch(`/api/posts?userId=${profileUser.id}`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json() as Promise<PostWithDetails[]>;
    },
    enabled: activeTab === "posts",
    retry: false,
  });

  const handleUnsavePost = async (postId: number) => {
    try {
      const response = await fetch(`/api/posts/${postId}/save`, {
        method: 'POST',
        credentials: 'include'
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          toast({
            title: "Unauthorized",
            description: "You are logged out. Logging in again...",
            variant: "destructive",
          });
          setTimeout(() => {
            window.location.href = "/api/login";
          }, 500);
          return;
        }
        throw new Error('Failed to unsave post');
      }
      
      refetchSavedPosts();
      toast({
        title: "Success",
        description: "Post removed from saved",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to unsave post",
        variant: "destructive",
      });
    }
  };

  const stats = userStats || {
    postsCount: 0,
    savedCount: 0,
    followingCount: 0,
    followersCount: 0,
  };

  return (
    <div className="space-y-8">
      {/* Profile Header */}
      <Card className="shadow-lg">
        <CardContent className="p-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-6">
              <Avatar className="w-20 h-20">
                <AvatarImage src={profileUser.profileImageUrl || ""} alt={profileUser.firstName || "User"} />
                <AvatarFallback className="text-2xl">
                  {profileUser.firstName?.[0] || profileUser.email?.[0] || "U"}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-3xl font-bold text-foreground">
                  {profileUser.firstName && profileUser.lastName 
                    ? `${profileUser.firstName} ${profileUser.lastName}`
                    : profileUser.firstName || "Anonymous User"
                  }
                </h1>
                {profileUser.bio && (
                  <p className="text-muted-foreground mt-2">{profileUser.bio}</p>
                )}
                <div className="flex items-center space-x-6 mt-4 text-sm text-muted-foreground">
                  <span>📝 {statsLoading ? '...' : stats.postsCount} Posts</span>
                  {isOwnProfile && <span>💾 {statsLoading ? '...' : stats.savedCount} Saved</span>}
                  <span>👥 {statsLoading ? '...' : stats.followingCount} Following</span>
                  <span>👥 {statsLoading ? '...' : stats.followersCount} Followers</span>
                </div>
              </div>
            </div>
            {isOwnProfile && (
              <Button variant="outline">
                <Settings className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Dashboard Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-flex">
          <TabsTrigger value="posts" className="flex items-center space-x-2">
            <User className="w-4 h-4" />
            <span>Posts</span>
          </TabsTrigger>
          {isOwnProfile && (
            <TabsTrigger value="saved" className="flex items-center space-x-2">
              <span>💾</span>
              <span>Saved</span>
            </TabsTrigger>
          )}
          <TabsTrigger value="following" className="flex items-center space-x-2">
            <span>👥</span>
            <span>Following</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center space-x-2">
            <Settings className="w-4 h-4" />
            <span>Settings</span>
          </TabsTrigger>
        </TabsList>

        {/* Posts Tab */}
        <TabsContent value="posts" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">
              Posts ({statsLoading ? '...' : stats.postsCount})
            </h3>
          </div>

          {userPostsLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : userPosts.length === 0 ? (
            <div className="text-center py-12">
              <h3 className="text-lg font-semibold text-muted-foreground mb-2">No posts yet</h3>
              <p className="text-muted-foreground">
                {isOwnProfile ? "Share your first crypto experience!" : "This user hasn't posted anything yet."}
              </p>
            </div>
          ) : (
            <div className="grid gap-4">
              {userPosts.map((post) => {
                const categoryStyle = categoryStyles[post.category as keyof typeof categoryStyles] || 
                  { bg: 'bg-muted', text: 'text-foreground', emoji: '📝' };

                return (
                  <Card key={post.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        {post.imageUrl && (
                          <img 
                            src={post.imageUrl} 
                            alt="Post thumbnail"
                            className="w-16 h-16 rounded-lg object-cover flex-shrink-0"
                          />
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge className={cn(categoryStyle.bg, categoryStyle.text, "text-xs")}>
                              {categoryStyle.emoji} {post.category.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </Badge>
                            <span className="text-muted-foreground text-sm">
                              {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                            </span>
                          </div>
                          <h4 className="font-semibold text-foreground mb-1 line-clamp-1">{post.title}</h4>
                          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{post.content}</p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                              <span className="flex items-center space-x-1">
                                <Heart className="w-4 h-4" />
                                <span>{post.likesCount}</span>
                              </span>
                              <span className="flex items-center space-x-1">
                                <MessageCircle className="w-4 h-4" />
                                <span>{post.commentsCount}</span>
                              </span>
                              <span className="flex items-center space-x-1">
                                <Share2 className="w-4 h-4" />
                                <span>{post.sharesCount}</span>
                              </span>
                            </div>
                            <Button size="sm" variant="ghost" className="text-crypto-blue hover:text-crypto-purple">
                              <ExternalLink className="w-4 h-4 mr-1" />
                              View
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* Saved Posts Tab */}
        {isOwnProfile && (
          <TabsContent value="saved" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">
                💾 Saved Posts ({statsLoading ? '...' : stats.savedCount})
              </h3>
              <Select value={savedPostsSort} onValueChange={setSavedPostsSort}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent">Recently Saved</SelectItem>
                  <SelectItem value="category">By Category</SelectItem>
                  <SelectItem value="popular">Most Popular</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {savedPostsLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : savedPosts.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-lg font-semibold text-muted-foreground mb-2">No saved posts</h3>
                <p className="text-muted-foreground">
                  Start saving posts that you find interesting or want to read later.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {savedPosts.map((post) => {
                  const categoryStyle = categoryStyles[post.category as keyof typeof categoryStyles] || 
                    { bg: 'bg-muted', text: 'text-foreground', emoji: '📝' };

                  return (
                    <Card key={post.id} className="hover:shadow-lg transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-4">
                          {post.imageUrl && (
                            <img 
                              src={post.imageUrl} 
                              alt="Post thumbnail"
                              className="w-16 h-16 rounded-lg object-cover flex-shrink-0"
                            />
                          )}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center space-x-2 mb-2">
                              <Badge className={cn(categoryStyle.bg, categoryStyle.text, "text-xs")}>
                                {categoryStyle.emoji} {post.category.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                              </Badge>
                              <span className="text-muted-foreground text-sm">
                                by {post.user.firstName || "Anonymous"} • {post.likesCount} likes • {post.commentsCount} comments
                              </span>
                            </div>
                            <h4 className="font-semibold text-foreground mb-1 line-clamp-1">{post.title}</h4>
                            <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{post.content}</p>
                            <div className="flex items-center space-x-3">
                              <Button size="sm" variant="ghost" className="text-crypto-blue hover:text-crypto-purple">
                                <ExternalLink className="w-4 h-4 mr-1" />
                                View Post
                              </Button>
                              <Button 
                                size="sm" 
                                variant="ghost"
                                onClick={() => handleUnsavePost(post.id)}
                                className="text-red-500 hover:text-red-600"
                              >
                                <BookmarkMinus className="w-4 h-4 mr-1" />
                                Unsave
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
        )}

        {/* Following Tab */}
        <TabsContent value="following" className="space-y-6">
          <div className="text-center py-12">
            <h3 className="text-lg font-semibold text-muted-foreground mb-2">Following feature coming soon</h3>
            <p className="text-muted-foreground">
              Connect with other crypto enthusiasts and follow their activities.
            </p>
          </div>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <div className="text-center py-12">
            <h3 className="text-lg font-semibold text-muted-foreground mb-2">Settings coming soon</h3>
            <p className="text-muted-foreground">
              Customize your profile, notification preferences, and privacy settings.
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

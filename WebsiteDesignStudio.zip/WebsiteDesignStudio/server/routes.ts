import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import connectPg from "connect-pg-simple";
// import { setupAuth, isAuthenticated } from "./replitAuth"; // Disabled for VPS deployment
import { uploadProfileImage, uploadLogo, processProfileImage, processLogo } from "./upload";
import { 
  registerUser, 
  loginUser, 
  web3Login, 
  requireRole, 
  canCreatePosts, 
  isAdmin,
  attachUser 
} from "./auth";
import { 
  signupSchema, 
  loginSchema, 
  web3LoginSchema, 
  insertPostSchema,
  insertCommentSchema,
  insertAnnouncementSchema 
} from "@shared/schema";
import { ZodError } from "zod";
import { NotificationService } from "./notificationService";

// Simple authentication middleware for VPS deployment
const isAuthenticated = (req: any, res: any, next: any) => {
  if (req.session?.user) {
    return next();
  }
  return res.status(401).json({ message: "Unauthorized" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session management for VPS deployment
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  
  app.set("trust proxy", 1);
  app.use(session({
    secret: process.env.SESSION_SECRET || 'fallback-secret-change-in-production',
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production', // Only use secure cookies in production
      maxAge: sessionTtl,
    },
  }));

  // Use user attachment middleware
  app.use(attachUser);

  // New authentication routes for email/password and Web3
  app.post('/api/auth/signup', async (req: any, res) => {
    try {
      const validatedData = signupSchema.parse(req.body);
      const user = await registerUser(validatedData);
      
      // Set session
      (req.session as any).user = { id: user.id, role: user.role };
      
      res.status(201).json({
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        walletAddress: user.walletAddress,
      });
    } catch (error: any) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(400).json({ message: error.message });
    }
  });

  app.post('/api/auth/login', async (req: any, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      const user = await loginUser(validatedData);
      
      // Set session
      (req.session as any).user = { id: user.id, role: user.role };
      
      res.json({
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        walletAddress: user.walletAddress,
      });
    } catch (error: any) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(400).json({ message: error.message });
    }
  });

  app.post('/api/auth/web3-login', async (req: any, res) => {
    try {
      const validatedData = web3LoginSchema.parse(req.body);
      const user = await web3Login(validatedData);
      
      // Set session
      (req.session as any).user = { id: user.id, role: user.role };
      
      res.json({
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        walletAddress: user.walletAddress,
      });
    } catch (error: any) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(400).json({ message: error.message });
    }
  });

  // Logout route
  app.post('/api/auth/logout', (req: any, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Could not log out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  // Auth routes
  app.get('/api/auth/user', async (req: any, res) => {
    try {
      if ((req.session as any)?.user?.id) {
        const user = await storage.getUser((req.session as any).user.id);
        if (user && user.isActive) {
          return res.json({
            id: user.id,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            role: user.role,
            walletAddress: user.walletAddress,
            bio: user.bio,
            profileImageUrl: user.profileImageUrl,
            createdAt: user.createdAt,
          });
        }
      }
      
      // Fallback to Replit auth
      if (req.user?.claims?.sub) {
        const user = await storage.getUser(req.user.claims.sub);
        return res.json(user);
      }
      
      res.status(401).json({ message: "Unauthorized" });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Update user profile
  app.patch('/api/auth/profile', async (req: any, res) => {
    try {
      let userId: string;
      
      // Get user ID from session or Replit auth
      if ((req.session as any)?.user?.id) {
        userId = (req.session as any).user.id;
      } else if (req.user?.claims?.sub) {
        userId = req.user.claims.sub;
      } else {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const { firstName, lastName, bio, profileImageUrl } = req.body;
      
      const updatedUser = await storage.updateUser(userId, {
        firstName,
        lastName,
        bio,
        profileImageUrl,
      });

      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({
        id: updatedUser.id,
        email: updatedUser.email,
        firstName: updatedUser.firstName,
        lastName: updatedUser.lastName,
        role: updatedUser.role,
        walletAddress: updatedUser.walletAddress,
        bio: updatedUser.bio,
        profileImageUrl: updatedUser.profileImageUrl,
        createdAt: updatedUser.createdAt,
      });
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Upload profile image
  app.post('/api/auth/upload-profile-image', uploadProfileImage, async (req: any, res) => {
    try {
      let userId: string;
      
      // Get user ID from session
      if ((req.session as any)?.user?.id) {
        userId = (req.session as any).user.id;
      } else {
        return res.status(401).json({ message: "Unauthorized" });
      }

      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }

      // Process and save the image
      const imageUrl = await processProfileImage(req.file);
      
      // Update user profile with new image URL
      const updatedUser = await storage.updateUser(userId, {
        profileImageUrl: imageUrl,
      });

      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({ profileImageUrl: imageUrl });
    } catch (error) {
      console.error("Error uploading profile image:", error);
      res.status(500).json({ message: "Failed to upload image" });
    }
  });

  // Admin routes - User management
  app.get('/api/admin/users', async (req: any, res) => {
    try {
      let userRole: string;

      // Check session-based auth first
      if ((req.session as any)?.user?.id) {
        const user = await storage.getUser((req.session as any).user.id);
        if (!user || !user.isActive) {
          return res.status(401).json({ message: "Unauthorized" });
        }
        userRole = user.role;
      } else if (req.user?.claims?.sub) {
        // Fallback to Replit auth
        const user = await storage.getUser(req.user.claims.sub);
        if (!user) {
          return res.status(401).json({ message: "Unauthorized" });
        }
        userRole = user.role || "admin";
      } else {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Check if user is admin
      if (!isAdmin(userRole)) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { limit = '50', offset = '0' } = req.query;
      const users = await storage.getAllUsers({
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      });

      res.json(users.map(user => ({
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        walletAddress: user.walletAddress,
        isActive: user.isActive,
        createdAt: user.createdAt,
      })));
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Promote user role
  app.patch('/api/admin/users/:id/role', async (req: any, res) => {
    try {
      let userRole: string;

      // Check session-based auth first
      if ((req.session as any)?.user?.id) {
        const user = await storage.getUser((req.session as any).user.id);
        if (!user || !user.isActive) {
          return res.status(401).json({ message: "Unauthorized" });
        }
        userRole = user.role;
      } else if (req.user?.claims?.sub) {
        // Fallback to Replit auth
        const user = await storage.getUser(req.user.claims.sub);
        if (!user) {
          return res.status(401).json({ message: "Unauthorized" });
        }
        userRole = user.role || "admin";
      } else {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Check if user is admin
      if (!isAdmin(userRole)) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { role } = req.body;
      if (!['user', 'creator', 'admin'].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }

      const updatedUser = await storage.updateUserRole(req.params.id, role);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({
        id: updatedUser.id,
        email: updatedUser.email,
        firstName: updatedUser.firstName,
        lastName: updatedUser.lastName,
        role: updatedUser.role,
        walletAddress: updatedUser.walletAddress,
        isActive: updatedUser.isActive,
      });
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Site settings management
  app.get('/api/settings', async (req, res) => {
    try {
      const settings = await storage.getSiteSettings();
      const settingsObj = settings.reduce((acc, setting) => {
        acc[setting.key] = setting.value || '';
        return acc;
      }, {} as Record<string, string>);
      
      res.json(settingsObj);
    } catch (error) {
      console.error("Error fetching site settings:", error);
      res.status(500).json({ message: "Failed to fetch site settings" });
    }
  });

  app.patch('/api/admin/settings', async (req: any, res) => {
    try {
      let userRole: string;

      // Check session-based auth first
      if ((req.session as any)?.user?.id) {
        const user = await storage.getUser((req.session as any).user.id);
        if (!user || !user.isActive) {
          return res.status(401).json({ message: "Unauthorized" });
        }
        userRole = user.role;
      } else if (req.user?.claims?.sub) {
        // Fallback to Replit auth
        const user = await storage.getUser(req.user.claims.sub);
        if (!user) {
          return res.status(401).json({ message: "Unauthorized" });
        }
        userRole = user.role || "admin";
      } else {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Check if user is admin
      if (!isAdmin(userRole)) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const settings = req.body;
      const updatedSettings = [];

      for (const [key, value] of Object.entries(settings)) {
        const updatedSetting = await storage.updateSiteSetting(key, value as string);
        if (updatedSetting) {
          updatedSettings.push(updatedSetting);
        }
      }

      res.json({ message: "Settings updated successfully", updatedSettings });
    } catch (error) {
      console.error("Error updating site settings:", error);
      res.status(500).json({ message: "Failed to update site settings" });
    }
  });

  // Post routes - only admin and creator can create posts
  app.post("/api/posts", async (req: any, res) => {
    try {
      let userId: string;
      let userRole: string;

      // Check session-based auth first
      if ((req.session as any)?.user?.id) {
        const user = await storage.getUser((req.session as any).user.id);
        if (!user || !user.isActive) {
          return res.status(401).json({ message: "Unauthorized" });
        }
        userId = user.id;
        userRole = user.role;
      } else if (req.user?.claims?.sub) {
        // Fallback to Replit auth
        const user = await storage.getUser(req.user.claims.sub);
        if (!user) {
          return res.status(401).json({ message: "Unauthorized" });
        }
        userId = user.id;
        userRole = user.role || "admin"; // Default Replit users to admin for backward compatibility
      } else {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Check if user can create posts
      if (!canCreatePosts(userRole)) {
        return res.status(403).json({ message: "Only admins and creators can create posts" });
      }

      const validatedData = insertPostSchema.parse(req.body);
      const postData = {
        ...validatedData,
        userId,
      };

      const post = await storage.createPost(postData);
      res.status(201).json(post);
    } catch (error) {
      console.error("Error creating post:", error);
      res.status(400).json({ message: "Failed to create post" });
    }
  });

  app.get("/api/posts", async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const { 
        category, 
        search, 
        sortBy = 'recent', 
        limit = '20', 
        offset = '0' 
      } = req.query;

      const posts = await storage.getPosts({
        category: category as string,
        search: search as string,
        sortBy: sortBy as 'recent' | 'popular' | 'trending',
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
        userId,
      });

      res.json(posts);
    } catch (error) {
      console.error("Error fetching posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  app.get("/api/posts/:id", async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const postId = parseInt(req.params.id);
      
      const post = await storage.getPostById(postId, userId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      res.json(post);
    } catch (error) {
      console.error("Error fetching post:", error);
      res.status(500).json({ message: "Failed to fetch post" });
    }
  });

  app.put("/api/posts/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const postId = parseInt(req.params.id);
      
      // Check if user owns the post
      const existingPost = await storage.getPostById(postId);
      if (!existingPost || existingPost.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to edit this post" });
      }
      
      const updates = insertPostSchema.partial().parse(req.body);
      const updatedPost = await storage.updatePost(postId, updates);
      
      res.json(updatedPost);
    } catch (error) {
      console.error("Error updating post:", error);
      res.status(400).json({ message: "Failed to update post" });
    }
  });

  app.delete("/api/posts/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const postId = parseInt(req.params.id);
      
      // Check if user owns the post
      const existingPost = await storage.getPostById(postId);
      if (!existingPost || existingPost.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to delete this post" });
      }
      
      const success = await storage.deletePost(postId);
      res.json({ success });
    } catch (error) {
      console.error("Error deleting post:", error);
      res.status(500).json({ message: "Failed to delete post" });
    }
  });

  // Post interactions
  app.post("/api/posts/:id/like", async (req: any, res) => {
    try {
      let userId: string;
      let user: any;
      
      if (req.session?.user?.id) {
        userId = req.session.user.id;
        user = await storage.getUser(userId);
      } else if (req.user?.claims?.sub) {
        userId = req.user.claims.sub;
        user = await storage.getUser(userId);
      } else {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const postId = parseInt(req.params.id);
      
      // Get post details to find the owner
      const post = await storage.getPostById(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const isLiked = await storage.toggleLike(userId, postId);
      
      // Create notification if post was liked (not unliked) and not self-like
      if (isLiked && post.userId !== userId) {
        await NotificationService.createLikeNotification(
          postId,
          post.userId,
          userId,
          user?.firstName || user?.email || 'Someone'
        );
      }
      
      res.json({ isLiked });
    } catch (error) {
      console.error("Error toggling like:", error);
      res.status(500).json({ message: "Failed to toggle like" });
    }
  });

  app.post("/api/posts/:id/save", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const postId = parseInt(req.params.id);
      
      const isSaved = await storage.toggleSave(userId, postId);
      res.json({ isSaved });
    } catch (error) {
      console.error("Error toggling save:", error);
      res.status(500).json({ message: "Failed to toggle save" });
    }
  });

  app.get("/api/users/:id/saved-posts", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const requestedUserId = req.params.id;
      
      // Users can only see their own saved posts
      if (userId !== requestedUserId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const { limit = '20', offset = '0' } = req.query;
      const savedPosts = await storage.getSavedPosts(userId, {
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      });
      
      res.json(savedPosts);
    } catch (error) {
      console.error("Error fetching saved posts:", error);
      res.status(500).json({ message: "Failed to fetch saved posts" });
    }
  });

  // Comments
  app.post("/api/posts/:id/comments", async (req: any, res) => {
    try {
      let userId: string;
      let user: any;
      
      if (req.session?.user?.id) {
        userId = req.session.user.id;
        user = await storage.getUser(userId);
      } else if (req.user?.claims?.sub) {
        userId = req.user.claims.sub;
        user = await storage.getUser(userId);
      } else {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const postId = parseInt(req.params.id);
      
      // Get post details to find the owner
      const post = await storage.getPostById(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const commentData = insertCommentSchema.parse({
        ...req.body,
        userId,
        postId,
      });
      
      const comment = await storage.createComment(commentData);
      
      // Create notification for post owner if not commenting on own post
      if (post.userId !== userId) {
        await NotificationService.createCommentNotification(
          postId,
          post.userId,
          userId,
          user?.firstName || user?.email || 'Someone'
        );
      }
      
      res.json(comment);
    } catch (error) {
      console.error("Error creating comment:", error);
      res.status(400).json({ message: "Failed to create comment" });
    }
  });

  app.get("/api/posts/:id/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const comments = await storage.getCommentsByPostId(postId);
      res.json(comments);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  // User routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const userId = req.params.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.get("/api/users/:id/stats", async (req, res) => {
    try {
      const userId = req.params.id;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  app.post("/api/users/:id/follow", isAuthenticated, async (req: any, res) => {
    try {
      const followerId = req.user.claims.sub;
      const followingId = req.params.id;
      
      const isFollowing = await storage.toggleFollow(followerId, followingId);
      res.json({ isFollowing });
    } catch (error) {
      console.error("Error toggling follow:", error);
      res.status(500).json({ message: "Failed to toggle follow" });
    }
  });

  // Search
  app.get("/api/search", async (req, res) => {
    try {
      const { q: query, category, limit = '20', offset = '0' } = req.query;
      
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const results = await storage.searchPosts(query as string, {
        category: category as string,
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      });
      
      res.json(results);
    } catch (error) {
      console.error("Error searching posts:", error);
      res.status(500).json({ message: "Failed to search posts" });
    }
  });

  // Announcements
  app.get("/api/announcements", async (req, res) => {
    try {
      const announcements = await storage.getActiveAnnouncements();
      res.json(announcements);
    } catch (error) {
      console.error("Error fetching announcements:", error);
      res.status(500).json({ message: "Failed to fetch announcements" });
    }
  });

  app.post("/api/announcements", isAuthenticated, async (req: any, res) => {
    try {
      // Note: In a real application, you'd check if the user is an admin
      const announcementData = insertAnnouncementSchema.parse(req.body);
      const announcement = await storage.createAnnouncement(announcementData);
      res.json(announcement);
    } catch (error) {
      console.error("Error creating announcement:", error);
      res.status(400).json({ message: "Failed to create announcement" });
    }
  });

  app.put("/api/announcements/:id", isAuthenticated, async (req: any, res) => {
    try {
      const announcementId = parseInt(req.params.id);
      const updates = insertAnnouncementSchema.partial().parse(req.body);
      
      const updatedAnnouncement = await storage.updateAnnouncement(announcementId, updates);
      res.json(updatedAnnouncement);
    } catch (error) {
      console.error("Error updating announcement:", error);
      res.status(400).json({ message: "Failed to update announcement" });
    }
  });

  app.delete("/api/announcements/:id", isAuthenticated, async (req: any, res) => {
    try {
      const announcementId = parseInt(req.params.id);
      const success = await storage.deactivateAnnouncement(announcementId);
      res.json({ success });
    } catch (error) {
      console.error("Error deactivating announcement:", error);
      res.status(500).json({ message: "Failed to deactivate announcement" });
    }
  });

  // Notification routes
  app.get("/api/notifications", async (req: any, res) => {
    try {
      let userId: string;
      
      if (req.session?.user?.id) {
        userId = req.session.user.id;
      } else if (req.user?.claims?.sub) {
        const user = await storage.getUser(req.user.claims.sub);
        if (!user) {
          return res.status(401).json({ message: "Unauthorized" });
        }
        userId = user.id;
      } else {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const { limit = '50', offset = '0', unreadOnly = 'false' } = req.query;
      
      const notifications = await storage.getNotifications(userId, {
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
        unreadOnly: unreadOnly === 'true',
      });
      
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.patch("/api/notifications/:id/read", async (req: any, res) => {
    try {
      let userId: string;
      
      if (req.session?.user?.id) {
        userId = req.session.user.id;
      } else if (req.user?.claims?.sub) {
        const user = await storage.getUser(req.user.claims.sub);
        if (!user) {
          return res.status(401).json({ message: "Unauthorized" });
        }
        userId = user.id;
      } else {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const notificationId = parseInt(req.params.id);
      const success = await storage.markNotificationAsRead(notificationId);
      
      res.json({ success });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.patch("/api/notifications/mark-all-read", async (req: any, res) => {
    try {
      let userId: string;
      
      if (req.session?.user?.id) {
        userId = req.session.user.id;
      } else if (req.user?.claims?.sub) {
        const user = await storage.getUser(req.user.claims.sub);
        if (!user) {
          return res.status(401).json({ message: "Unauthorized" });
        }
        userId = user.id;
      } else {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const success = await storage.markAllNotificationsAsRead(userId);
      res.json({ success });
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ message: "Failed to mark all notifications as read" });
    }
  });

  app.delete("/api/notifications/:id", async (req: any, res) => {
    try {
      let userId: string;
      
      if (req.session?.user?.id) {
        userId = req.session.user.id;
      } else if (req.user?.claims?.sub) {
        const user = await storage.getUser(req.user.claims.sub);
        if (!user) {
          return res.status(401).json({ message: "Unauthorized" });
        }
        userId = user.id;
      } else {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const notificationId = parseInt(req.params.id);
      const success = await storage.deleteNotification(notificationId);
      
      res.json({ success });
    } catch (error) {
      console.error("Error deleting notification:", error);
      res.status(500).json({ message: "Failed to delete notification" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

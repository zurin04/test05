# VPS Deployment Troubleshooting Guide

## Common Issues and Solutions

### Issue 1: Application Fails to Start with PM2

**Symptoms:**
- `pm2 logs cryptohub` shows continuous restarts
- Application exits immediately after starting
- No error messages in logs

**Solution:**

1. **Check if build completed:**
```bash
cd /var/www/cryptohub
ls -la dist/  # Should contain index.js
```

2. **Test the build manually:**
```bash
cd /var/www/cryptohub
npm run build
```

3. **Test start command manually:**
```bash
cd /var/www/cryptohub
source .env
npm start
```

4. **Fix PM2 configuration:**
```bash
cd /var/www/cryptohub
pm2 delete all
pm2 start ecosystem.config.cjs --env production
pm2 logs cryptohub
```

### Issue 2: Database Connection Problems

**Symptoms:**
- "DATABASE_URL must be set" error
- Connection refused errors

**Solution:**

1. **Verify PostgreSQL is running:**
```bash
sudo systemctl status postgresql
sudo systemctl start postgresql  # if not running
```

2. **Test database connection:**
```bash
cd /var/www/cryptohub
source .env
psql $DATABASE_URL -c "SELECT 1;"
```

3. **Recreate database if needed:**
```bash
sudo -u postgres psql
DROP DATABASE IF EXISTS cryptohub_db;
DROP USER IF EXISTS cryptohub_user;
CREATE USER cryptohub_user WITH PASSWORD 'your_password' SUPERUSER;
CREATE DATABASE cryptohub_db OWNER cryptohub_user;
\q
```

4. **Update environment variables:**
```bash
cd /var/www/cryptohub
nano .env  # Update DATABASE_URL with correct credentials
```

### Issue 3: Build Failures

**Symptoms:**
- Build process hangs or fails
- Out of memory errors during build

**Solution:**

1. **Increase memory for build:**
```bash
cd /var/www/cryptohub
export NODE_OPTIONS="--max-old-space-size=4096"
npm run build
```

2. **Clean and rebuild:**
```bash
cd /var/www/cryptohub
rm -rf node_modules dist
npm install
npm run build
```

3. **For low-memory VPS (< 2GB RAM):**
```bash
# Create swap file
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
# Then try building again
```

### Issue 4: Permission Problems

**Symptoms:**
- Cannot write to directories
- PM2 startup failures

**Solution:**

1. **Fix ownership:**
```bash
sudo chown -R $USER:$USER /var/www/cryptohub
```

2. **Set correct permissions:**
```bash
chmod +x /var/www/cryptohub/manage.sh
chmod +x /var/www/cryptohub/deploy-vps.sh
```

### Issue 5: Port Already in Use

**Symptoms:**
- "Port 5000 already in use" error
- Application won't start

**Solution:**

1. **Find and kill process:**
```bash
sudo lsof -i :5000
sudo kill -9 <PID>
```

2. **Or change port in ecosystem.config.cjs:**
```javascript
env: {
  NODE_ENV: 'production',
  PORT: 3000,  // Change from 5000
  // ...
}
```

3. **Update Nginx configuration:**
```bash
sudo nano /etc/nginx/sites-available/cryptohub
# Change proxy_pass to http://localhost:3000
sudo nginx -t && sudo systemctl reload nginx
```

## Manual Deployment Steps (If Script Fails)

If the automated deployment script fails, follow these manual steps:

### 1. System Setup
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Install Nginx and PM2
sudo apt install -y nginx
sudo npm install -g pm2
```

### 2. Database Setup
```bash
# Create database user and database
sudo -u postgres psql << EOF
CREATE USER cryptohub_user WITH PASSWORD 'your_secure_password' SUPERUSER;
CREATE DATABASE cryptohub_db OWNER cryptohub_user;
\q
EOF
```

### 3. Application Setup
```bash
# Create app directory
sudo mkdir -p /var/www/cryptohub
sudo chown $USER:$USER /var/www/cryptohub

# Copy your files to the directory
cd /var/www/cryptohub

# Create .env file
cat > .env << EOF
DATABASE_URL=postgresql://cryptohub_user:your_secure_password@localhost:5432/cryptohub_db
SESSION_SECRET=$(openssl rand -hex 32)
NODE_ENV=production
PORT=5000
PGHOST=localhost
PGPORT=5432
PGUSER=cryptohub_user
PGPASSWORD=your_secure_password
PGDATABASE=cryptohub_db
EOF

# Install dependencies and build
npm install
npm run db:push
npm run build
```

### 4. Process Management
```bash
# Start with PM2
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup
```

### 5. Web Server Setup
```bash
# Configure Nginx (copy config from deploy-vps.sh)
sudo nano /etc/nginx/sites-available/cryptohub
sudo ln -s /etc/nginx/sites-available/cryptohub /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
```

## Verification Commands

```bash
# Check application status
pm2 status
pm2 logs cryptohub

# Check database
psql $DATABASE_URL -c "SELECT COUNT(*) FROM users;"

# Check web server
curl http://localhost:5000
curl http://localhost

# Check system resources
free -h
df -h
```

## Getting Help

If issues persist:

1. **Collect logs:**
```bash
pm2 logs cryptohub > app.log
sudo tail -n 50 /var/log/nginx/error.log > nginx.log
```

2. **Check system resources:**
```bash
htop
df -h
free -h
```

3. **Restart services:**
```bash
pm2 restart all
sudo systemctl restart nginx postgresql
```

Remember to replace `your_secure_password` with the actual password generated during deployment.
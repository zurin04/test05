#!/bin/bash

# CryptoHub Platform - Production VPS Deployment
# Optimized one-click deployment for Ubuntu VPS

set -e

echo "======================================"
echo "    CryptoHub Platform Deployment    "
echo "======================================"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }
print_header() { echo -e "${BLUE}[STEP]${NC} $1"; }

# Check prerequisites
[[ $EUID -eq 0 ]] && { print_error "Do not run as root. Use a regular user with sudo privileges."; exit 1; }
command -v sudo >/dev/null || { print_error "sudo is required but not installed."; exit 1; }

# System Information
print_header "System Information"
echo "OS: $(lsb_release -d | cut -f2)"
echo "Architecture: $(uname -m)"
echo "Available Memory: $(free -h | awk '/^Mem:/ {print $2}')"
echo "Available Disk: $(df -h / | awk 'NR==2 {print $4}')"
echo ""

# Install system dependencies
print_header "Installing System Dependencies"
print_status "Updating package lists..."
sudo apt update -y

print_status "Installing core dependencies..."
sudo apt install -y \
    curl \
    wget \
    gnupg \
    postgresql \
    postgresql-contrib \
    nginx \
    certbot \
    python3-certbot-nginx \
    python3 \
    python3-pip \
    build-essential \
    git \
    ufw \
    htop \
    unzip

# Install Node.js 20
print_header "Installing Node.js 20"
if ! command -v node &>/dev/null; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
else
    print_status "Node.js already installed: $(node --version)"
fi

# Install PM2
print_status "Installing PM2 process manager..."
sudo npm install -g pm2 2>/dev/null || print_warning "PM2 already installed"

# Start services
print_header "Starting System Services"
sudo systemctl enable --now postgresql nginx
print_status "PostgreSQL and Nginx services started"

# Setup application directory
APP_DIR="/var/www/cryptohub"
print_header "Setting Up Application"
print_status "Creating application directory: $APP_DIR"
sudo mkdir -p $APP_DIR && sudo chown $USER:$USER $APP_DIR

# Copy application files (assumes script is run from project directory)
if [ -f "package.json" ]; then
    print_status "Copying application files..."
    cp -r . $APP_DIR/
    cd $APP_DIR
else
    print_error "package.json not found. Please run this script from your CryptoHub project directory."
    exit 1
fi

# Generate secure credentials
print_header "Generating Security Credentials"
DB_PASSWORD=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -hex 32)
print_status "Generated secure database password and session secret"

# Setup PostgreSQL database
print_header "Setting Up PostgreSQL Database"
print_status "Creating database and user..."
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS cryptohub_db;
DROP USER IF EXISTS cryptohub_user;
CREATE USER cryptohub_user WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE cryptohub_db OWNER cryptohub_user;
GRANT ALL PRIVILEGES ON DATABASE cryptohub_db TO cryptohub_user;
\q
EOF

# Create environment file
print_header "Creating Environment Configuration"
cat > .env << ENV
# Database Configuration
DATABASE_URL=postgresql://cryptohub_user:$DB_PASSWORD@localhost:5432/cryptohub_db
PGHOST=localhost
PGPORT=5432
PGUSER=cryptohub_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=cryptohub_db

# Application Configuration
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000

# Replit Environment Variables (for compatibility)
REPL_ID=cryptohub-production
REPLIT_DOMAINS=your-domain.com
ENV

print_status "Environment configuration created"

# Install dependencies
print_header "Installing Application Dependencies"
print_status "Installing Node.js packages..."
npm install --production=false

# Test database connection
print_header "Testing Database Connection"
print_status "Verifying database connectivity..."
if ! PGPASSWORD="$DB_PASSWORD" psql -h localhost -U cryptohub_user -d cryptohub_db -c "SELECT 1;" >/dev/null 2>&1; then
    print_error "Database connection failed. Check PostgreSQL setup."
    exit 1
fi
print_status "Database connection successful"

# Setup database schema
print_header "Initializing Database Schema"
export DATABASE_URL="postgresql://cryptohub_user:$DB_PASSWORD@localhost:5432/cryptohub_db"
export SESSION_SECRET
export NODE_ENV=production

print_status "Pushing database schema..."
if ! npm run db:push 2>&1; then
    print_error "Database schema setup failed."
    exit 1
fi

# Create initial admin user (optional)
print_status "Setting up initial data..."
sudo -u postgres psql -d cryptohub_db << 'EOF'
-- Insert initial site settings
INSERT INTO site_settings (key, value) VALUES 
('site_name', 'CryptoHub'),
('description', 'The ultimate crypto community platform'),
('twitter_url', 'https://twitter.com/cryptohub'),
('telegram_url', 'https://t.me/cryptohub'),
('discord_url', 'https://discord.gg/cryptohub')
ON CONFLICT (key) DO NOTHING;

-- Insert welcome announcement
INSERT INTO announcements (title, content, type, is_active, created_at, updated_at) VALUES 
('Welcome to CryptoHub!', 'Welcome to the ultimate crypto community platform for testnets, airdrops, and Web3 opportunities!', 'info', true, NOW(), NOW())
ON CONFLICT DO NOTHING;
EOF

# Build application
print_header "Building Application"
print_status "Building frontend and backend..."
export NODE_OPTIONS="--max-old-space-size=4096"
if ! timeout 600 npm run build; then
    print_warning "Build timed out, trying with reduced memory..."
    export NODE_OPTIONS="--max-old-space-size=2048"
    if ! timeout 300 npm run build; then
        print_error "Build failed. You may need to build locally and upload the dist folder."
        exit 1
    fi
fi
print_status "Application built successfully"

# Configure PM2
print_header "Configuring Process Manager"
mkdir -p logs

cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: 'cryptohub',
    script: 'npm',
    args: 'start',
    instances: 1,
    autorestart: true,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: 'postgresql://cryptohub_user:$DB_PASSWORD@localhost:5432/cryptohub_db',
      SESSION_SECRET: '$SESSION_SECRET',
      PGHOST: 'localhost',
      PGPORT: '5432',
      PGUSER: 'cryptohub_user',
      PGPASSWORD: '$DB_PASSWORD',
      PGDATABASE: 'cryptohub_db',
      REPL_ID: 'cryptohub-production'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
}
EOF

# Configure Nginx
print_header "Configuring Nginx Web Server"
sudo tee /etc/nginx/sites-available/cryptohub > /dev/null << 'EOF'
server {
    listen 80;
    server_name _;
    client_max_body_size 100M;
    
    # Security headers
    add_header X-Frame-Options DENY always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self' https:;" always;
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
    
    # Static file caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        try_files $uri @proxy;
    }
    
    # Main application proxy
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
    
    # Fallback for static files
    location @proxy {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

# Enable Nginx site
sudo ln -sf /etc/nginx/sites-available/cryptohub /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
print_status "Nginx configured and reloaded"

# Start application
print_header "Starting CryptoHub Application"
pm2 delete all 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save
print_status "Application started with PM2"

# Setup PM2 startup
print_status "Configuring PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Verify application
print_header "Verifying Application Status"
sleep 10
if pm2 list | grep -q "cryptohub.*online"; then
    print_status "✓ Application is running successfully!"
else
    print_error "✗ Application failed to start. Check logs with: pm2 logs cryptohub"
    exit 1
fi

# Configure firewall
print_header "Configuring Security"
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp
print_status "Firewall configured (SSH, HTTP, HTTPS allowed)"

# Create management script
print_header "Creating Management Tools"
cat > manage.sh << 'SCRIPT'
#!/bin/bash

# CryptoHub Management Script
# Usage: ./manage.sh [command] [options]

set -e

# Load environment variables
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

BACKUP_DIR="/var/backups/cryptohub"
APP_DIR="/var/www/cryptohub"

show_help() {
    echo "CryptoHub Management Script"
    echo "=========================="
    echo ""
    echo "Commands:"
    echo "  start           Start the application"
    echo "  stop            Stop the application"
    echo "  restart         Restart the application"
    echo "  status          Show application status"
    echo "  logs            Show application logs"
    echo "  backup          Create database backup"
    echo "  restore [file]  Restore database from backup"
    echo "  update          Safe update from git repository"
    echo "  ssl [domain]    Setup SSL certificate"
    echo "  health          Run health check"
    echo "  monitor         Show real-time monitoring"
    echo ""
}

backup_database() {
    echo "Creating database backup..."
    mkdir -p $BACKUP_DIR
    BACKUP_FILE="$BACKUP_DIR/backup_$(date +%Y%m%d_%H%M%S).sql"
    
    if PGPASSWORD="$PGPASSWORD" pg_dump -h localhost -U cryptohub_user cryptohub_db > $BACKUP_FILE; then
        echo "✓ Backup saved to: $BACKUP_FILE"
        # Keep only last 10 backups
        ls -t $BACKUP_DIR/backup_*.sql | tail -n +11 | xargs -r rm
        echo "✓ Old backups cleaned up (keeping last 10)"
    else
        echo "✗ Backup failed!"
        exit 1
    fi
}

restore_database() {
    local backup_file=$1
    if [ -z "$backup_file" ]; then
        echo "Available backups:"
        ls -la $BACKUP_DIR/backup_*.sql 2>/dev/null || echo "No backups found"
        echo "Usage: ./manage.sh restore /path/to/backup.sql"
        exit 1
    fi
    
    if [ ! -f "$backup_file" ]; then
        echo "✗ Backup file not found: $backup_file"
        exit 1
    fi
    
    echo "⚠️  WARNING: This will replace all current data!"
    echo "Press Enter to continue or Ctrl+C to cancel..."
    read
    
    echo "Stopping application..."
    pm2 stop cryptohub
    
    echo "Restoring database from: $backup_file"
    if PGPASSWORD="$PGPASSWORD" psql -h localhost -U cryptohub_user -d cryptohub_db -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;" && \
       PGPASSWORD="$PGPASSWORD" psql -h localhost -U cryptohub_user cryptohub_db < $backup_file; then
        echo "✓ Database restored successfully"
        pm2 start cryptohub
        echo "✓ Application restarted"
    else
        echo "✗ Restore failed!"
        pm2 start cryptohub
        exit 1
    fi
}

safe_update() {
    echo "Starting safe update process..."
    
    # Create pre-update backup
    echo "Creating pre-update backup..."
    backup_database
    
    # Stop application
    echo "Stopping application..."
    pm2 stop cryptohub
    
    # Update code
    echo "Pulling latest changes..."
    if git pull; then
        echo "✓ Code updated"
    else
        echo "✗ Git pull failed!"
        pm2 start cryptohub
        exit 1
    fi
    
    # Install dependencies
    echo "Installing dependencies..."
    if npm install; then
        echo "✓ Dependencies updated"
    else
        echo "✗ npm install failed!"
        pm2 start cryptohub
        exit 1
    fi
    
    # Update database schema
    echo "Updating database schema..."
    if npm run db:push; then
        echo "✓ Database schema updated"
    else
        echo "✗ Database migration failed!"
        pm2 start cryptohub
        exit 1
    fi
    
    # Build application
    echo "Building application..."
    export NODE_OPTIONS="--max-old-space-size=4096"
    if timeout 600 npm run build; then
        echo "✓ Application built"
    else
        echo "✗ Build failed!"
        pm2 start cryptohub
        exit 1
    fi
    
    # Start application
    echo "Starting application..."
    pm2 start cryptohub
    
    # Verify application is running
    sleep 5
    if pm2 list | grep -q "cryptohub.*online"; then
        echo "✓ Update completed successfully!"
    else
        echo "✗ Application failed to start after update!"
        echo "Check logs with: pm2 logs cryptohub"
    fi
}

ssl_setup() {
    local domain=$1
    if [ -z "$domain" ]; then
        echo "Usage: ./manage.sh ssl yourdomain.com"
        exit 1
    fi
    
    echo "Setting up SSL for domain: $domain"
    
    # Update Nginx config
    sudo sed -i "s/server_name _;/server_name $domain;/" /etc/nginx/sites-available/cryptohub
    sudo nginx -t && sudo systemctl reload nginx
    
    # Get SSL certificate
    if sudo certbot --nginx -d "$domain" --non-interactive --agree-tos --email "admin@$domain" --redirect; then
        echo "✓ SSL certificate installed successfully!"
        # Setup automatic renewal
        (sudo crontab -l 2>/dev/null | grep -v "certbot renew"; echo "0 12 * * * /usr/bin/certbot renew --quiet") | sudo crontab -
        echo "✓ Automatic renewal configured"
    else
        echo "✗ SSL certificate installation failed. Check DNS configuration."
        exit 1
    fi
}

health_check() {
    echo "CryptoHub Platform - Health Check"
    echo "================================="
    echo ""
    
    # Check application status
    if pm2 list | grep -q "cryptohub.*online"; then
        echo "✓ Application: Running"
    else
        echo "✗ Application: Not running"
    fi
    
    # Check database connection
    if PGPASSWORD="$PGPASSWORD" psql -h localhost -U cryptohub_user -d cryptohub_db -c "SELECT 1;" >/dev/null 2>&1; then
        echo "✓ Database: Connected"
    else
        echo "✗ Database: Connection failed"
    fi
    
    # Check Nginx
    if sudo nginx -t >/dev/null 2>&1; then
        echo "✓ Nginx: Configuration valid"
    else
        echo "✗ Nginx: Configuration error"
    fi
    
    # Check disk space
    DISK_USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
    if [ $DISK_USAGE -lt 80 ]; then
        echo "✓ Disk Space: ${DISK_USAGE}% used"
    else
        echo "⚠ Disk Space: ${DISK_USAGE}% used (Warning: >80%)"
    fi
    
    # Check memory usage
    MEMORY_USAGE=$(free | awk 'NR==2{printf "%.1f", $3*100/$2}')
    echo "ℹ Memory Usage: ${MEMORY_USAGE}%"
    
    # Check application response
    if curl -s http://localhost:5000 >/dev/null; then
        echo "✓ Application: Responding to requests"
    else
        echo "✗ Application: Not responding"
    fi
}

monitor() {
    echo "CryptoHub Real-time Monitoring"
    echo "=============================="
    echo "Press Ctrl+C to exit"
    echo ""
    
    while true; do
        clear
        echo "$(date)"
        echo "============================================"
        pm2 monit
        sleep 5
    done
}

# Command handling
case "${1:-help}" in
    "start")
        pm2 start cryptohub
        ;;
    "stop")
        pm2 stop cryptohub
        ;;
    "restart")
        pm2 restart cryptohub
        ;;
    "status")
        pm2 status cryptohub
        ;;
    "logs")
        pm2 logs cryptohub
        ;;
    "backup")
        backup_database
        ;;
    "restore")
        restore_database "$2"
        ;;
    "update")
        safe_update
        ;;
    "ssl")
        ssl_setup "$2"
        ;;
    "health")
        health_check
        ;;
    "monitor")
        monitor
        ;;
    "help"|*)
        show_help
        ;;
esac
SCRIPT

chmod +x manage.sh
print_status "Management script created: ./manage.sh"

# Final status report
print_header "Deployment Complete!"
echo ""
echo "🎉 CryptoHub has been successfully deployed!"
echo ""
echo "📊 Application Status:"
pm2 status cryptohub
echo ""
echo "🔗 Access Information:"
echo "  Local: http://localhost:5000"
echo "  Public: http://$(curl -s ipecho.net/plain || echo 'YOUR_SERVER_IP')"
echo ""
echo "🔧 Management Commands:"
echo "  ./manage.sh status    - Check application status"
echo "  ./manage.sh logs      - View application logs"
echo "  ./manage.sh restart   - Restart application"
echo "  ./manage.sh backup    - Create database backup"
echo "  ./manage.sh ssl [domain] - Setup SSL certificate"
echo "  ./manage.sh health    - Run health check"
echo ""
echo "📝 Important Files:"
echo "  Configuration: .env"
echo "  Logs: ./logs/"
echo "  Backups: /var/backups/cryptohub/"
echo ""
echo "🔐 Database Credentials:"
echo "  Database: cryptohub_db"
echo "  Username: cryptohub_user"
echo "  Password: [stored in .env file]"
echo ""
echo "🚀 Next Steps:"
echo "  1. Set up your domain DNS to point to this server"
echo "  2. Run: ./manage.sh ssl yourdomain.com"
echo "  3. Create admin user via the web interface"
echo "  4. Configure site settings in admin panel"
echo ""
echo "✅ Deployment completed successfully!"
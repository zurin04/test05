#!/bin/bash

# CryptoHub VPS Deployment Script - Complete Solution
# Fixes all deployment errors and provides production-ready setup

set -e
trap 'echo "Error on line $LINENO. Exit code: $?" >&2' ERR

echo "=========================================="
echo "    CryptoHub VPS Deployment v2.0        "
echo "=========================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() { echo -e "${GREEN}[$(date +'%H:%M:%S')]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }
header() { echo -e "${BLUE}▶${NC} $1"; }
success() { echo -e "${GREEN}✓${NC} $1"; }

# Check system and prerequisites
header "System Check"
[[ $EUID -eq 0 ]] && { error "Do not run as root. Use regular user with sudo."; exit 1; }
command -v sudo >/dev/null || { error "sudo required but not installed."; exit 1; }

log "OS: $(lsb_release -d 2>/dev/null | cut -f2 || echo 'Unknown')"
log "Memory: $(free -h | awk '/^Mem:/ {print $2}')"
log "Disk: $(df -h / | awk 'NR==2 {print $4}')"

# Detect installation mode
if [ -d "/var/www/cryptohub" ] && [ -f "/var/www/cryptohub/package.json" ]; then
    log "Existing installation detected - will repair/update"
    INSTALL_MODE="repair"
    APP_DIR="/var/www/cryptohub"
else
    log "Fresh installation starting"
    INSTALL_MODE="fresh"
    APP_DIR="/var/www/cryptohub"
fi

# Install system dependencies
header "Installing System Dependencies"
log "Updating package lists..."
sudo apt update -qq

PACKAGES=(
    curl wget gnupg lsb-release
    postgresql postgresql-contrib
    nginx certbot python3-certbot-nginx
    build-essential git htop unzip
    software-properties-common
)

log "Installing packages..."
sudo apt install -y "${PACKAGES[@]}"

# Node.js 20 LTS
if ! command -v node &>/dev/null || [[ $(node -v | cut -d'.' -f1 | tr -d 'v') -lt 18 ]]; then
    log "Installing Node.js 20 LTS..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi
log "Node.js: $(node -v)"

# PM2
if ! command -v pm2 &>/dev/null; then
    log "Installing PM2..."
    sudo npm install -g pm2@latest
fi

# Start services
sudo systemctl enable --now postgresql nginx
success "System dependencies installed"

# Setup application
header "Setting Up Application"
if [ "$INSTALL_MODE" = "fresh" ]; then
    if [ ! -f "package.json" ]; then
        error "package.json not found. Run this script from your CryptoHub project directory."
        exit 1
    fi
    
    sudo mkdir -p "$APP_DIR"
    sudo chown "$USER:$USER" "$APP_DIR"
    log "Copying application files..."
    cp -r . "$APP_DIR/"
fi

cd "$APP_DIR"

# Clean previous builds
log "Cleaning previous builds..."
rm -rf dist/ node_modules/.vite 2>/dev/null || true

# Generate credentials
DB_PASSWORD=$(openssl rand -base64 32 | tr -d '=+/' | cut -c1-25)
SESSION_SECRET=$(openssl rand -hex 32)

success "Application directory ready"

# Database setup
header "Database Configuration"

if ! sudo systemctl is-active --quiet postgresql; then
    sudo systemctl start postgresql
    sleep 2
fi

log "Creating database and user..."
sudo -u postgres psql << 'DBEOF'
DROP DATABASE IF EXISTS cryptohub_db;
DROP USER IF EXISTS cryptohub_user;
CREATE USER cryptohub_user WITH PASSWORD '$DB_PASSWORD' CREATEDB;
CREATE DATABASE cryptohub_db OWNER cryptohub_user;
GRANT ALL PRIVILEGES ON DATABASE cryptohub_db TO cryptohub_user;
\c cryptohub_db
GRANT ALL ON SCHEMA public TO cryptohub_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO cryptohub_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO cryptohub_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO cryptohub_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO cryptohub_user;
DBEOF

# Create environment file
log "Creating environment configuration..."
cat > .env << 'ENVEOF'
# Database Configuration
DATABASE_URL=postgresql://cryptohub_user:$DB_PASSWORD@localhost:5432/cryptohub_db
PGHOST=localhost
PGPORT=5432
PGUSER=cryptohub_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=cryptohub_db

# Application Configuration
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000

# Replit Compatibility
REPL_ID=cryptohub-production
REPLIT_DOMAINS=localhost
REPLIT_DB_URL=postgresql://cryptohub_user:$DB_PASSWORD@localhost:5432/cryptohub_db
ENVEOF

# Replace variables in .env file
sed -i "s/\$DB_PASSWORD/$DB_PASSWORD/g" .env
sed -i "s/\$SESSION_SECRET/$SESSION_SECRET/g" .env

source .env

# Test database connection
log "Testing database connection..."
if ! psql "$DATABASE_URL" -c "SELECT version();" >/dev/null 2>&1; then
    error "Database connection failed!"
    exit 1
fi

success "Database configured successfully"

# Build application
header "Building Application"

log "Installing Node.js dependencies..."
export npm_config_fund=false
export npm_config_audit=false
npm install --production=false --silent

log "Setting up database schema..."
npm run db:push || {
    error "Database schema setup failed"
    exit 1
}

log "Building application..."
export NODE_OPTIONS="--max-old-space-size=4096"

if ! timeout 900 npm run build; then
    warn "Build failed with 4GB memory, trying with 2GB..."
    export NODE_OPTIONS="--max-old-space-size=2048"
    if ! timeout 600 npm run build; then
        error "Build failed. Check system memory and try building locally."
        exit 1
    fi
fi

if [ ! -f "dist/index.js" ]; then
    error "Build output missing: dist/index.js not found"
    exit 1
fi

success "Application built successfully"

# PM2 configuration
header "Configuring Process Manager"

mkdir -p logs uploads

pm2 delete all 2>/dev/null || true
pm2 kill 2>/dev/null || true

# Create PM2 config
cat > ecosystem.config.js << 'PMEOF'
module.exports = {
  apps: [{
    name: 'cryptohub',
    script: 'dist/index.js',
    cwd: process.cwd(),
    instances: 1,
    exec_mode: 'fork',
    
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true,
    
    max_memory_restart: '1G',
    node_args: '--max-old-space-size=1024',
    
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s',
    restart_delay: 4000,
    
    kill_timeout: 5000,
    wait_ready: true,
    listen_timeout: 8000
  }]
};
PMEOF

log "Starting application..."
pm2 start ecosystem.config.js
pm2 save

STARTUP_CMD=$(pm2 startup systemd -u "$USER" --hp "$HOME" 2>&1 | grep "sudo env" || true)
if [ -n "$STARTUP_CMD" ]; then
    eval "$STARTUP_CMD"
fi

success "PM2 configured and application started"

# Nginx configuration
header "Configuring Web Server"

sudo tee /etc/nginx/sites-available/cryptohub >/dev/null << 'NGINXEOF'
server {
    listen 80;
    listen [::]:80;
    server_name _;
    
    client_max_body_size 50M;
    client_body_timeout 60s;
    client_header_timeout 60s;
    
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/javascript
        application/xml+rss
        application/json
        image/svg+xml;
    
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot|webp)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        add_header Vary "Accept-Encoding";
        try_files $uri @proxy;
    }
    
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
    
    location @proxy {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
NGINXEOF

sudo ln -sf /etc/nginx/sites-available/cryptohub /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

if ! sudo nginx -t; then
    error "Nginx configuration test failed"
    exit 1
fi

sudo systemctl reload nginx
success "Nginx configured successfully"

# Verify deployment
header "Verifying Deployment"

log "Waiting for application startup..."
sleep 8

if ! pm2 list | grep -q "cryptohub.*online"; then
    error "Application not running in PM2"
    pm2 status
    pm2 logs cryptohub --lines 20
    exit 1
fi

log "Testing HTTP endpoint..."
for i in {1..5}; do
    if curl -f -s http://localhost:5000/health >/dev/null 2>&1 || curl -f -s http://localhost:5000 >/dev/null 2>&1; then
        success "HTTP endpoint responding"
        break
    fi
    if [ $i -eq 5 ]; then
        warn "HTTP endpoint not responding, but PM2 shows online"
    else
        log "Attempt $i/5: Waiting for HTTP response..."
        sleep 3
    fi
done

# Add initial data
log "Setting up initial data..."
psql "$DATABASE_URL" << 'INITEOF'
INSERT INTO site_settings (key, value) VALUES 
('site_name', 'CryptoHub'),
('description', 'Ultimate crypto community platform for testnets, airdrops, and Web3 opportunities'),
('twitter_url', 'https://twitter.com/cryptohub'),
('telegram_url', 'https://t.me/cryptohub'),
('discord_url', 'https://discord.gg/cryptohub')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

INSERT INTO announcements (title, content, type, is_active, created_at, updated_at) VALUES 
('🎉 Welcome to CryptoHub!', 'Welcome to the ultimate crypto community platform! Discover testnets, airdrops, and Web3 opportunities.', 'info', true, NOW(), NOW())
ON CONFLICT DO NOTHING;
INITEOF

success "Deployment verification completed"

# Security setup
header "Configuring Security"

sudo ufw --force enable >/dev/null 2>&1 || true
sudo ufw allow ssh >/dev/null 2>&1 || true
sudo ufw allow 'Nginx Full' >/dev/null 2>&1 || true
sudo ufw allow 80/tcp >/dev/null 2>&1 || true
sudo ufw allow 443/tcp >/dev/null 2>&1 || true

success "Security configured"

# Create management tools
header "Creating Management Tools"

cat > manage.sh << 'MGMTEOF'
#!/bin/bash
# CryptoHub Management Script

APP_DIR="/var/www/cryptohub"
cd "$APP_DIR" 2>/dev/null || { echo "Error: CryptoHub not found at $APP_DIR"; exit 1; }

case "$1" in
    start)
        pm2 start ecosystem.config.js
        echo "✓ CryptoHub started"
        ;;
    stop)
        pm2 stop cryptohub
        echo "✓ CryptoHub stopped"
        ;;
    restart)
        pm2 restart cryptohub
        echo "✓ CryptoHub restarted"
        ;;
    status)
        pm2 status cryptohub
        ;;
    logs)
        pm2 logs cryptohub "${2:---lines=50}"
        ;;
    monitor)
        pm2 monit
        ;;
    ssl)
        [[ -z "$2" ]] && { echo "Usage: $0 ssl domain.com"; exit 1; }
        sudo sed -i "s/server_name _;/server_name $2;/" /etc/nginx/sites-available/cryptohub
        sudo nginx -t && sudo systemctl reload nginx
        sudo certbot --nginx -d "$2" --non-interactive --agree-tos --email "admin@$2" --redirect
        echo "✓ SSL configured for $2"
        ;;
    backup)
        BACKUP_DIR="/var/backups/cryptohub"
        sudo mkdir -p "$BACKUP_DIR"
        BACKUP_FILE="$BACKUP_DIR/backup-$(date +%Y%m%d-%H%M%S).sql"
        pg_dump "$DATABASE_URL" > "$BACKUP_FILE"
        echo "✓ Backup created: $BACKUP_FILE"
        ;;
    restore)
        [[ -z "$2" ]] && { echo "Usage: $0 restore backup-file.sql"; exit 1; }
        psql "$DATABASE_URL" < "$2"
        echo "✓ Database restored from $2"
        ;;
    update)
        git pull
        npm install
        npm run build
        pm2 restart cryptohub
        echo "✓ Application updated"
        ;;
    health)
        echo "=== CryptoHub Health Check ==="
        echo -n "PM2 Status: "
        pm2 list | grep -q "cryptohub.*online" && echo "✓ Online" || echo "✗ Offline"
        echo -n "Database: "
        psql "$DATABASE_URL" -c "SELECT 1;" >/dev/null 2>&1 && echo "✓ Connected" || echo "✗ Error"
        echo -n "HTTP: "
        curl -f -s http://localhost:5000 >/dev/null 2>&1 && echo "✓ Responding" || echo "✗ No response"
        echo -n "Nginx: "
        sudo nginx -t >/dev/null 2>&1 && echo "✓ OK" || echo "✗ Config error"
        echo ""
        echo "System Resources:"
        df -h / | tail -1 | awk '{print "Disk: " $3 "/" $2 " (" $5 " used)"}'
        free -h | awk '/^Mem:/ {print "Memory: " $3 "/" $2}'
        ;;
    *)
        echo "CryptoHub Management Commands:"
        echo "  $0 start          - Start application"
        echo "  $0 stop           - Stop application" 
        echo "  $0 restart        - Restart application"
        echo "  $0 status         - Show status"
        echo "  $0 logs [lines]   - Show logs"
        echo "  $0 monitor        - Real-time monitoring"
        echo "  $0 ssl domain     - Setup SSL certificate"
        echo "  $0 backup         - Create database backup"
        echo "  $0 restore file   - Restore database"
        echo "  $0 update         - Update from git"
        echo "  $0 health         - Health check"
        exit 1
        ;;
esac
MGMTEOF

chmod +x manage.sh

success "Management tools created"

# Final status
echo ""
echo "=================================================="
success "CryptoHub deployment completed successfully!"
echo "=================================================="
echo ""
log "🌐 Access URLs:"
log "   Local: http://localhost:5000"
log "   Public: http://$(curl -s http://checkip.amazonaws.com 2>/dev/null || echo 'YOUR-SERVER-IP')"
echo ""
log "🔧 Management:"
log "   ./manage.sh status    - Check application status"
log "   ./manage.sh logs      - View application logs"
log "   ./manage.sh health    - Run health check"
log "   ./manage.sh ssl domain.com - Setup SSL certificate"
echo ""
log "📁 Important paths:"
log "   Application: $APP_DIR"
log "   Logs: pm2 logs cryptohub"
log "   Config: $APP_DIR/.env"
echo ""
log "🚀 Next steps:"
log "   1. Visit your application URL"
log "   2. Create your admin account (first user becomes admin)"
log "   3. Setup SSL: ./manage.sh ssl yourdomain.com"
log "   4. Monitor: ./manage.sh monitor"
echo ""
success "Your CryptoHub platform is ready!"
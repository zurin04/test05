#!/bin/bash

# CryptoHub VPS Deployment Script - Complete Solution
# Addresses all deployment errors and provides production-ready setup

set -e
trap 'echo "Error on line $LINENO. Exit code: $?" >&2' ERR

echo "=========================================="
echo "    CryptoHub VPS Deployment v2.0        "
echo "=========================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

log() { echo -e "${GREEN}[$(date +'%H:%M:%S')]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }
header() { echo -e "${BLUE}▶${NC} $1"; }
success() { echo -e "${GREEN}✓${NC} $1"; }

# Prerequisites check
check_system() {
    header "System Check"
    
    [[ $EUID -eq 0 ]] && { error "Do not run as root. Use regular user with sudo."; exit 1; }
    command -v sudo >/dev/null || { error "sudo required but not installed."; exit 1; }
    
    # System info
    log "OS: $(lsb_release -d 2>/dev/null | cut -f2 || echo 'Unknown')"
    log "Arch: $(uname -m)"
    log "Memory: $(free -h | awk '/^Mem:/ {print $2}')"
    log "Disk: $(df -h / | awk 'NR==2 {print $4}')"
    
    # Check if existing installation
    if [ -d "/var/www/cryptohub" ] && [ -f "/var/www/cryptohub/package.json" ]; then
        log "Existing installation detected - will repair/update"
        INSTALL_MODE="repair"
        APP_DIR="/var/www/cryptohub"
    else
        log "Fresh installation starting"
        INSTALL_MODE="fresh"
        APP_DIR="/var/www/cryptohub"
    fi
}

# Install system dependencies
install_system() {
    header "Installing System Dependencies"
    
    log "Updating package lists..."
    sudo apt update -qq
    
    # Essential packages
    PACKAGES=(
        curl wget gnupg lsb-release
        postgresql postgresql-contrib
        nginx certbot python3-certbot-nginx
        build-essential git htop unzip
        software-properties-common
    )
    
    log "Installing packages: ${PACKAGES[*]}"
    sudo apt install -y "${PACKAGES[@]}"
    
    # Node.js 20 LTS
    if ! command -v node &>/dev/null || [[ $(node -v | cut -d'.' -f1 | tr -d 'v') -lt 18 ]]; then
        log "Installing Node.js 20 LTS..."
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
        sudo apt install -y nodejs
    fi
    log "Node.js: $(node -v)"
    log "NPM: $(npm -v)"
    
    # PM2 process manager
    if ! command -v pm2 &>/dev/null; then
        log "Installing PM2..."
        sudo npm install -g pm2@latest
    fi
    
    # Start essential services
    sudo systemctl enable --now postgresql nginx
    success "System dependencies installed"
}

# Setup application directory and files
setup_application() {
    header "Setting Up Application"
    
    # Create/setup app directory
    if [ "$INSTALL_MODE" = "fresh" ]; then
        if [ ! -f "package.json" ]; then
            error "package.json not found. Run this script from your CryptoHub project directory."
            exit 1
        fi
        
        sudo mkdir -p "$APP_DIR"
        sudo chown "$USER:$USER" "$APP_DIR"
        log "Copying application files..."
        cp -r . "$APP_DIR/"
    fi
    
    cd "$APP_DIR"
    
    # Clean previous builds and temp files
    log "Cleaning previous builds..."
    rm -rf dist/ node_modules/.vite .next 2>/dev/null || true
    
    # Generate secure credentials
    DB_PASSWORD=$(openssl rand -base64 32 | tr -d '=+/' | cut -c1-25)
    SESSION_SECRET=$(openssl rand -hex 32)
    
    success "Application directory ready"
}

# Database setup with error handling
setup_database() {
    header "Database Configuration"
    
    # Check PostgreSQL status
    if ! sudo systemctl is-active --quiet postgresql; then
        sudo systemctl start postgresql
        sleep 2
    fi
    
    # Create database and user
    log "Creating database and user..."
    sudo -u postgres psql << EOF || {
        warn "Database creation had warnings, continuing..."
    }
-- Clean setup
DROP DATABASE IF EXISTS cryptohub_db;
DROP USER IF EXISTS cryptohub_user;

-- Create user with proper permissions
CREATE USER cryptohub_user WITH PASSWORD '$DB_PASSWORD' CREATEDB;
CREATE DATABASE cryptohub_db OWNER cryptohub_user;
GRANT ALL PRIVILEGES ON DATABASE cryptohub_db TO cryptohub_user;

-- Grant schema permissions
\c cryptohub_db
GRANT ALL ON SCHEMA public TO cryptohub_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO cryptohub_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO cryptohub_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO cryptohub_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO cryptohub_user;
EOF
    
    # Create environment configuration
    log "Creating environment configuration..."
    cat > .env << ENV
# Database Configuration
DATABASE_URL=postgresql://cryptohub_user:$DB_PASSWORD@localhost:5432/cryptohub_db
PGHOST=localhost
PGPORT=5432
PGUSER=cryptohub_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=cryptohub_db

# Application Configuration
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000

# Replit Compatibility
REPL_ID=cryptohub-production
REPLIT_DOMAINS=localhost
REPLIT_DB_URL=postgresql://cryptohub_user:$DB_PASSWORD@localhost:5432/cryptohub_db
ENV
    
    # Load environment
    source .env
    
    # Test database connection
    log "Testing database connection..."
    if ! psql "$DATABASE_URL" -c "SELECT version();" >/dev/null 2>&1; then
        error "Database connection failed!"
        exit 1
    fi
    
    success "Database configured successfully"
}

# Build application with error handling
build_application() {
    header "Building Application"
    
    # Install dependencies
    log "Installing Node.js dependencies..."
    export npm_config_fund=false
    export npm_config_audit=false
    npm install --production=false --silent
    
    # Database schema setup
    log "Setting up database schema..."
    npm run db:push || {
        error "Database schema setup failed"
        exit 1
    }
    
    # Build with memory management
    log "Building application..."
    export NODE_OPTIONS="--max-old-space-size=4096"
    
    if ! timeout 900 npm run build; then
        warn "Build failed with 4GB memory, trying with 2GB..."
        export NODE_OPTIONS="--max-old-space-size=2048"
        if ! timeout 600 npm run build; then
            error "Build failed. Check system memory and try building locally."
            exit 1
        fi
    fi
    
    # Verify build output
    if [ ! -f "dist/index.js" ]; then
        error "Build output missing: dist/index.js not found"
        exit 1
    fi
    
    # Test build
    log "Testing build..."
    timeout 10 node dist/index.js &
    BUILD_TEST_PID=$!
    sleep 3
    
    if kill -0 $BUILD_TEST_PID 2>/dev/null; then
        kill $BUILD_TEST_PID 2>/dev/null || true
        success "Build test successful"
    else
        warn "Build test inconclusive, continuing..."
    fi
    
    success "Application built successfully"
}

# Setup PM2 with robust configuration
setup_pm2() {
    header "Configuring Process Manager"
    
    # Create logs directory
    mkdir -p logs uploads
    
    # Stop any existing processes
    pm2 delete all 2>/dev/null || true
    pm2 kill 2>/dev/null || true
    
    # Create PM2 ecosystem file
    cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'cryptohub',
    script: 'dist/index.js',
    cwd: '$APP_DIR',
    instances: 1,
    exec_mode: 'fork',
    
    // Environment variables
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: '$DATABASE_URL',
      SESSION_SECRET: '$SESSION_SECRET',
      PGHOST: 'localhost',
      PGPORT: '5432',
      PGUSER: 'cryptohub_user',
      PGPASSWORD: '$DB_PASSWORD',
      PGDATABASE: 'cryptohub_db',
      REPL_ID: 'cryptohub-production',
      REPLIT_DOMAINS: 'localhost',
      REPLIT_DB_URL: '$DATABASE_URL'
    },
    
    // Logging
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true,
    
    // Resource management
    max_memory_restart: '1G',
    node_args: '--max-old-space-size=1024',
    
    // Restart behavior
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s',
    restart_delay: 4000,
    
    // Process management
    kill_timeout: 5000,
    wait_ready: true,
    listen_timeout: 8000,
    
    // Health monitoring
    health_check_grace_period: 3000,
    health_check_fatal_exceptions: false
  }]
};
EOF
    
    # Start application
    log "Starting application..."
    pm2 start ecosystem.config.js
    pm2 save
    
    # Setup startup script
    STARTUP_CMD=$(pm2 startup systemd -u "$USER" --hp "$HOME" 2>&1 | grep "sudo env" || true)
    if [ -n "$STARTUP_CMD" ]; then
        eval "$STARTUP_CMD"
    fi
    
    success "PM2 configured and application started"
}

# Nginx configuration with security headers
setup_nginx() {
    header "Configuring Web Server"
    
    # Create Nginx configuration
    sudo tee /etc/nginx/sites-available/cryptohub >/dev/null << 'EOF'
# CryptoHub Nginx Configuration
server {
    listen 80;
    listen [::]:80;
    server_name _;
    
    # File upload size
    client_max_body_size 50M;
    client_body_timeout 60s;
    client_header_timeout 60s;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "camera=(), microphone=(), geolocation=()" always;
    
    # Content Security Policy
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net https://*.replit.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self' https: wss: ws:; frame-src 'self';" always;
    
    # Compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/javascript
        application/xml+rss
        application/json
        image/svg+xml;
    
    # Static files with caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot|webp)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        add_header Vary "Accept-Encoding";
        try_files \$uri @proxy;
    }
    
    # API and uploads
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # Main application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
    
    # Fallback for static files
    location @proxy {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Health check endpoint
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
EOF
    
    # Enable site and remove default
    sudo ln -sf /etc/nginx/sites-available/cryptohub /etc/nginx/sites-enabled/
    sudo rm -f /etc/nginx/sites-enabled/default
    
    # Test and reload Nginx
    if ! sudo nginx -t; then
        error "Nginx configuration test failed"
        exit 1
    fi
    
    sudo systemctl reload nginx
    success "Nginx configured successfully"
}

# Verify deployment and create initial data
verify_deployment() {
    header "Verifying Deployment"
    
    # Wait for application to start
    log "Waiting for application startup..."
    sleep 8
    
    # Check PM2 status
    if ! pm2 list | grep -q "cryptohub.*online"; then
        error "Application not running in PM2"
        log "PM2 status:"
        pm2 status
        log "Recent logs:"
        pm2 logs cryptohub --lines 20
        exit 1
    fi
    
    # Test HTTP response
    log "Testing HTTP endpoint..."
    for i in {1..5}; do
        if curl -f -s http://localhost:5000/health >/dev/null 2>&1 || curl -f -s http://localhost:5000 >/dev/null 2>&1; then
            success "HTTP endpoint responding"
            break
        fi
        if [ $i -eq 5 ]; then
            warn "HTTP endpoint not responding, but PM2 shows online"
            log "This might be normal if authentication is required"
        else
            log "Attempt $i/5: Waiting for HTTP response..."
            sleep 3
        fi
    done
    
    # Add initial data
    log "Setting up initial data..."
    psql "$DATABASE_URL" << 'EOF' 2>/dev/null || warn "Initial data setup had warnings"
-- Site settings
INSERT INTO site_settings (key, value) VALUES 
('site_name', 'CryptoHub'),
('description', 'Ultimate crypto community platform for testnets, airdrops, and Web3 opportunities'),
('twitter_url', 'https://twitter.com/cryptohub'),
('telegram_url', 'https://t.me/cryptohub'),
('discord_url', 'https://discord.gg/cryptohub')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

-- Welcome announcement
INSERT INTO announcements (title, content, type, is_active, created_at, updated_at) VALUES 
('🎉 Welcome to CryptoHub!', 'Welcome to the ultimate crypto community platform! Discover testnets, airdrops, and Web3 opportunities. Connect with fellow crypto enthusiasts and stay ahead of the curve.', 'info', true, NOW(), NOW())
ON CONFLICT DO NOTHING;
EOF
    
    success "Deployment verification completed"
}

# Setup security and firewall
setup_security() {
    header "Configuring Security"
    
    # Firewall rules
    sudo ufw --force enable >/dev/null 2>&1 || true
    sudo ufw allow ssh >/dev/null 2>&1 || true
    sudo ufw allow 'Nginx Full' >/dev/null 2>&1 || true
    sudo ufw allow 80/tcp >/dev/null 2>&1 || true
    sudo ufw allow 443/tcp >/dev/null 2>&1 || true
    
    # Secure PostgreSQL
    sudo -u postgres psql << 'EOF' >/dev/null 2>&1 || true
ALTER USER postgres PASSWORD 'secure_postgres_password_change_me';
EOF
    
    success "Security configured"
}

# Create management tools
create_management() {
    header "Creating Management Tools"
    
    # Main management script
    cat > manage.sh << 'MGMT'
#!/bin/bash
# CryptoHub Management Script

APP_DIR="/var/www/cryptohub"
cd "$APP_DIR" 2>/dev/null || { echo "Error: CryptoHub not found at $APP_DIR"; exit 1; }

case "$1" in
    start)
        pm2 start ecosystem.config.js
        echo "✓ CryptoHub started"
        ;;
    stop)
        pm2 stop cryptohub
        echo "✓ CryptoHub stopped"
        ;;
    restart)
        pm2 restart cryptohub
        echo "✓ CryptoHub restarted"
        ;;
    status)
        pm2 status cryptohub
        ;;
    logs)
        pm2 logs cryptohub "${2:---lines=50}"
        ;;
    monitor)
        pm2 monit
        ;;
    ssl)
        [[ -z "$2" ]] && { echo "Usage: $0 ssl domain.com"; exit 1; }
        sudo sed -i "s/server_name _;/server_name $2;/" /etc/nginx/sites-available/cryptohub
        sudo nginx -t && sudo systemctl reload nginx
        sudo certbot --nginx -d "$2" --non-interactive --agree-tos --email "admin@$2" --redirect
        echo "✓ SSL configured for $2"
        ;;
    backup)
        BACKUP_DIR="/var/backups/cryptohub"
        sudo mkdir -p "$BACKUP_DIR"
        BACKUP_FILE="$BACKUP_DIR/backup-$(date +%Y%m%d-%H%M%S).sql"
        pg_dump "$DATABASE_URL" > "$BACKUP_FILE"
        echo "✓ Backup created: $BACKUP_FILE"
        ;;
    restore)
        [[ -z "$2" ]] && { echo "Usage: $0 restore backup-file.sql"; exit 1; }
        psql "$DATABASE_URL" < "$2"
        echo "✓ Database restored from $2"
        ;;
    update)
        git pull
        npm install
        npm run build
        pm2 restart cryptohub
        echo "✓ Application updated"
        ;;
    health)
        echo "=== CryptoHub Health Check ==="
        echo -n "PM2 Status: "
        pm2 list | grep -q "cryptohub.*online" && echo "✓ Online" || echo "✗ Offline"
        echo -n "Database: "
        psql "$DATABASE_URL" -c "SELECT 1;" >/dev/null 2>&1 && echo "✓ Connected" || echo "✗ Error"
        echo -n "HTTP: "
        curl -f -s http://localhost:5000 >/dev/null 2>&1 && echo "✓ Responding" || echo "✗ No response"
        echo -n "Nginx: "
        sudo nginx -t >/dev/null 2>&1 && echo "✓ OK" || echo "✗ Config error"
        echo ""
        echo "System Resources:"
        df -h / | tail -1 | awk '{print "Disk: " $3 "/" $2 " (" $5 " used)"}'
        free -h | awk '/^Mem:/ {print "Memory: " $3 "/" $2}'
        ;;
    *)
        echo "CryptoHub Management Commands:"
        echo "  $0 start          - Start application"
        echo "  $0 stop           - Stop application" 
        echo "  $0 restart        - Restart application"
        echo "  $0 status         - Show status"
        echo "  $0 logs [lines]   - Show logs"
        echo "  $0 monitor        - Real-time monitoring"
        echo "  $0 ssl domain     - Setup SSL certificate"
        echo "  $0 backup         - Create database backup"
        echo "  $0 restore file   - Restore database"
        echo "  $0 update         - Update from git"
        echo "  $0 health         - Health check"
        exit 1
        ;;
esac
MGMT
    
    chmod +x manage.sh
    
    # Create systemd service for additional reliability
    sudo tee /etc/systemd/system/cryptohub.service >/dev/null << EOF
[Unit]
Description=CryptoHub Application
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=forking
User=$USER
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/pm2 start ecosystem.config.js --no-daemon
ExecReload=/usr/bin/pm2 reload ecosystem.config.js
ExecStop=/usr/bin/pm2 stop ecosystem.config.js
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
    
    sudo systemctl daemon-reload
    sudo systemctl enable cryptohub >/dev/null 2>&1 || true
    
    success "Management tools created"
}

# Main execution flow
main() {
    # Run all setup functions
    check_system
    install_system
    setup_application
    setup_database
    build_application
    setup_pm2
    setup_nginx
    verify_deployment
    setup_security
    create_management
    
    # Final status report
    echo ""
    echo "=================================================="
    success "CryptoHub deployment completed successfully!"
    echo "=================================================="
    echo ""
    log "🌐 Access URLs:"
    log "   Local: http://localhost:5000"
    log "   Public: http://$(curl -s http://checkip.amazonaws.com 2>/dev/null || echo 'YOUR-SERVER-IP')"
    echo ""
    log "🔧 Management:"
    log "   ./manage.sh status    - Check application status"
    log "   ./manage.sh logs      - View application logs"
    log "   ./manage.sh health    - Run health check"
    log "   ./manage.sh ssl domain.com - Setup SSL certificate"
    echo ""
    log "📁 Important paths:"
    log "   Application: $APP_DIR"
    log "   Logs: pm2 logs cryptohub"
    log "   Config: $APP_DIR/.env"
    echo ""
    log "🚀 Next steps:"
    log "   1. Visit your application URL"
    log "   2. Create your admin account (first user becomes admin)"
    log "   3. Setup SSL: ./manage.sh ssl yourdomain.com"
    log "   4. Monitor: ./manage.sh monitor"
    echo ""
    success "Your CryptoHub platform is ready!"
}

# Execute main function
main "$@"
module.exports = {
  apps: [{
    name: 'cryptohub',
    script: 'npm',
    args: 'start',
    instances: 1,
    autorestart: true,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: 'postgresql://cryptohub_user:test_password_123@localhost:5432/cryptohub_db',
      SESSION_SECRET: 'test_session_secret'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log'
  }]
}

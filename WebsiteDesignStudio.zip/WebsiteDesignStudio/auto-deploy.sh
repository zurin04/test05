#!/bin/bash

# CryptoHub - Production VPS Deployment
# Based on proven successful deployment patterns

set -e

echo "======================================"
echo "CryptoHub Platform Deployment"
echo "======================================"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check prerequisites
[[ $EUID -eq 0 ]] && { print_error "Do not run as root. Use a regular user with sudo privileges."; exit 1; }
command -v sudo >/dev/null || { print_error "sudo is required but not installed."; exit 1; }

# Install system dependencies
print_status "Installing system dependencies..."
sudo apt update -y && sudo apt install -y curl wget gnupg postgresql postgresql-contrib nginx certbot python3-certbot-nginx python3 build-essential

# Install Node.js 20
if ! command -v node &>/dev/null; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi

# Install PM2
sudo npm install -g pm2 2>/dev/null || print_warning "PM2 already installed"

# Start services
sudo systemctl enable --now postgresql nginx

# Setup application
APP_DIR="/var/www/cryptohub"
print_status "Setting up application..."
sudo mkdir -p $APP_DIR && sudo chown $USER:$USER $APP_DIR
cp -r . $APP_DIR/ && cd $APP_DIR

# Generate secure credentials
DB_PASSWORD=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -hex 32)

# Create database and user
print_status "Setting up PostgreSQL database..."
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS cryptohub_db;
DROP USER IF EXISTS cryptohub_user;
CREATE USER cryptohub_user WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE cryptohub_db OWNER cryptohub_user;
GRANT ALL PRIVILEGES ON DATABASE cryptohub_db TO cryptohub_user;
\q
EOF

# Create environment file
print_status "Creating environment configuration..."
cat > .env << ENV
DATABASE_URL=postgresql://cryptohub_user:$DB_PASSWORD@localhost:5432/cryptohub_db
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
HOST=0.0.0.0
PGHOST=localhost
PGPORT=5432
PGUSER=cryptohub_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=cryptohub_db
REPL_ID=cryptohub-production
ENV

# Install dependencies 
print_status "Installing dependencies..."
npm install

# Setup database schema and seed data
print_status "Initializing database..."

# URL encode the password to handle special characters
if command -v python3 >/dev/null 2>&1; then
    DB_PASSWORD_ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$DB_PASSWORD', safe=''))")
else
    print_warning "Python3 not available, using password as-is (may cause issues with special characters)"
    DB_PASSWORD_ENCODED="$DB_PASSWORD"
fi
export DATABASE_URL="postgresql://cryptohub_user:$DB_PASSWORD_ENCODED@localhost:5432/cryptohub_db"
export SESSION_SECRET
export NODE_ENV=production

# Test database connection first
print_status "Testing database connection..."
if ! PGPASSWORD="$DB_PASSWORD" psql -h localhost -U cryptohub_user -d cryptohub_db -c "SELECT 1;" >/dev/null 2>&1; then
    print_error "Database connection failed. Check PostgreSQL setup."
    exit 1
fi

print_status "Pushing database schema..."
# Try with encoded URL first, then fallback to direct connection
if ! npm run db:push 2>&1; then
    print_warning "Schema push with encoded URL failed, trying direct connection..."
    # Try with raw password
    export DATABASE_URL="postgresql://cryptohub_user:$DB_PASSWORD@localhost:5432/cryptohub_db"
    if ! npm run db:push 2>&1; then
        print_error "Database schema push failed with both URL formats."
        exit 1
    fi
fi

# Update .env file with working DATABASE_URL
print_status "Updating environment configuration with working database URL..."
cat > .env << ENV
DATABASE_URL=$DATABASE_URL
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
HOST=0.0.0.0
PGHOST=localhost
PGPORT=5432
PGUSER=cryptohub_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=cryptohub_db
REPL_ID=cryptohub-production
REPLIT_DOMAINS=localhost
ENV

# Build application with extended timeout and memory optimization
print_status "Building application..."
export NODE_OPTIONS="--max-old-space-size=4096"
timeout 600 npm run build || {
    print_warning "Build timed out or failed, trying fallback strategy..."
    # Fallback strategy for resource-constrained VPS
    export NODE_OPTIONS="--max-old-space-size=2048"
    timeout 300 npm run build || {
        print_error "Build failed even with fallback strategy. Check available memory and try building locally."
        exit 1
    }
}

# Configure PM2 and services
print_status "Configuring services..."
mkdir -p logs

# Determine which URL format worked
WORKING_DB_URL="$DATABASE_URL"

cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: 'cryptohub',
    script: 'npm',
    args: 'start',
    instances: 1,
    autorestart: true,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: '$WORKING_DB_URL',
      SESSION_SECRET: '$SESSION_SECRET',
      HOST: '0.0.0.0',
      PGHOST: 'localhost',
      PGPORT: '5432',
      PGUSER: 'cryptohub_user',
      PGPASSWORD: '$DB_PASSWORD',
      PGDATABASE: 'cryptohub_db',
      REPL_ID: 'cryptohub-production',
      REPLIT_DOMAINS: 'localhost'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log'
  }]
}
EOF

# Configure Nginx
sudo tee /etc/nginx/sites-available/cryptohub > /dev/null << 'EOF'
server {
    listen 80;
    server_name _;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
}
EOF

sudo ln -sf /etc/nginx/sites-available/cryptohub /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Start application
print_status "Starting application with PM2..."
pm2 delete all 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save

# Setup PM2 startup
print_status "Configuring PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Verify application is running
print_status "Verifying application startup..."
sleep 5
if pm2 list | grep -q "cryptohub.*online"; then
    print_status "Application started successfully!"
else
    print_error "Application failed to start. Check logs with: pm2 logs cryptohub"
    exit 1
fi

# Setup security and management
print_status "Finalizing setup..."
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp

# Populate database with initial data
print_status "Adding initial data..."
PGPASSWORD="$DB_PASSWORD" psql -h localhost -U cryptohub_user -d cryptohub_db << 'INITEOF'
-- Site settings
INSERT INTO site_settings (key, value) VALUES 
('site_name', 'CryptoHub'),
('description', 'Ultimate crypto community platform for testnets, airdrops, and Web3 opportunities'),
('twitter_url', 'https://twitter.com/cryptohub'),
('telegram_url', 'https://t.me/cryptohub'),
('discord_url', 'https://discord.gg/cryptohub')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

-- Welcome announcement
INSERT INTO announcements (title, content, type, is_active, created_at, updated_at) VALUES 
('🎉 Welcome to CryptoHub!', 'Welcome to the ultimate crypto community platform! Discover testnets, airdrops, and Web3 opportunities.', 'info', true, NOW(), NOW())
ON CONFLICT DO NOTHING;
INITEOF

# Create management script
cat > manage.sh << 'SCRIPT'
#!/bin/bash

# Load environment variables
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

case "$1" in
    start)
        pm2 start ecosystem.config.cjs
        echo "✅ CryptoHub started"
        ;;
    stop)
        pm2 stop cryptohub
        echo "✅ CryptoHub stopped"
        ;;
    restart)
        pm2 restart cryptohub
        echo "✅ CryptoHub restarted"
        ;;
    status)
        pm2 status cryptohub
        echo ""
        echo "🌐 URLs:"
        echo "  Local: http://localhost:${PORT:-5000}"
        echo "  Public: http://$(curl -s http://checkip.amazonaws.com 2>/dev/null)"
        ;;
    logs)
        pm2 logs cryptohub "${2:---lines=50}"
        ;;
    ssl)
        [[ -z "$2" ]] && { echo "Usage: $0 ssl domain.com"; exit 1; }
        echo "🔒 Setting up SSL for $2..."
        sudo sed -i "s/server_name _;/server_name $2;/" /etc/nginx/sites-available/cryptohub
        sudo nginx -t && sudo systemctl reload nginx
        sudo certbot --nginx -d "$2" --non-interactive --agree-tos --email "admin@$2" --redirect
        echo "✅ SSL configured for $2"
        ;;
    backup)
        BACKUP_DIR="/var/backups/cryptohub"
        mkdir -p "$BACKUP_DIR"
        BACKUP_FILE="$BACKUP_DIR/backup-$(date +%Y%m%d-%H%M%S).sql"
        echo "💾 Creating backup..."
        PGPASSWORD="$PGPASSWORD" pg_dump -h localhost -U cryptohub_user cryptohub_db > "$BACKUP_FILE"
        echo "✅ Backup created: $BACKUP_FILE"
        ;;
    health)
        echo "🏥 === CryptoHub Health Check ==="
        
        # PM2 Status
        echo -n "PM2: "
        pm2 list | grep -q "cryptohub.*online" && echo "✅ Online" || echo "❌ Offline"
        
        # Database
        echo -n "Database: "
        PGPASSWORD="$PGPASSWORD" psql -h localhost -U cryptohub_user -d cryptohub_db -c "SELECT 1;" >/dev/null 2>&1 && echo "✅ Connected" || echo "❌ Error"
        
        # HTTP
        echo -n "HTTP: "
        curl -f -s http://localhost:${PORT:-5000} >/dev/null 2>&1 && echo "✅ Responding" || echo "❌ No response"
        
        # Nginx
        echo -n "Nginx: "
        sudo nginx -t >/dev/null 2>&1 && echo "✅ OK" || echo "❌ Config error"
        ;;
    *)
        echo "🎛️  CryptoHub Management Commands:"
        echo "  $0 start     - Start application"
        echo "  $0 stop      - Stop application"
        echo "  $0 restart   - Restart application"
        echo "  $0 status    - Show status"
        echo "  $0 logs      - Show logs"
        echo "  $0 ssl domain - Setup SSL"
        echo "  $0 backup    - Create backup"
        echo "  $0 health    - Health check"
        ;;
esac
SCRIPT

chmod +x manage.sh

# Get server IP for display
SERVER_IP=$(curl -s http://checkip.amazonaws.com 2>/dev/null || echo "localhost")

# Final success report
echo ""
echo "🎉 =================================================="
echo "🎉      CryptoHub Deployment Successful!          "
echo "🎉 =================================================="
echo ""
echo "🌐 Access Your Application:"
echo "   👉 Local: http://localhost:5000"
echo "   👉 Public: http://$SERVER_IP"
echo ""
echo "🔧 Management Commands:"
echo "   ./manage.sh status     - Check application status"
echo "   ./manage.sh logs       - View application logs"
echo "   ./manage.sh health     - Complete health check"
echo "   ./manage.sh ssl domain.com - Setup SSL certificate"
echo ""
echo "📊 Database Information:"
echo "   Database: cryptohub_db"
echo "   User: cryptohub_user"
echo "   Host: localhost:5432"
echo ""
echo "🚀 Next Steps:"
echo "   1. Visit your application URL"
echo "   2. Sign up (first user becomes admin)"
echo "   3. Configure site settings in admin panel"
echo "   4. Setup SSL: ./manage.sh ssl yourdomain.com"
echo ""
echo "✅ Your CryptoHub platform is ready for production!"
echo ""
#!/bin/bash

# CryptoHub Fully Automated VPS Deployment
# Complete one-click solution with automatic database generation

set -e
trap 'echo "Error on line $LINENO. Exit code: $?" >&2' ERR

echo "============================================="
echo "    CryptoHub Automated VPS Deployment      "
echo "============================================="

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

log() { echo -e "${GREEN}[$(date +'%H:%M:%S')]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }
header() { echo -e "${BLUE}▶${NC} $1"; }
success() { echo -e "${GREEN}✓${NC} $1"; }

# Auto-detect environment and setup variables
setup_environment() {
    header "Environment Setup"
    
    # Check if running as root
    [[ $EUID -eq 0 ]] && { error "Do not run as root. Use regular user with sudo."; exit 1; }
    
    # Auto-detect installation mode
    if [ -d "/var/www/cryptohub" ] && [ -f "/var/www/cryptohub/package.json" ]; then
        INSTALL_MODE="repair"
        APP_DIR="/var/www/cryptohub"
        log "Existing installation detected - repair mode"
    else
        INSTALL_MODE="fresh"
        APP_DIR="/var/www/cryptohub"
        log "Fresh installation mode"
    fi
    
    # Auto-generate secure credentials
    DB_NAME="cryptohub_db"
    DB_USER="cryptohub_user"
    DB_PASSWORD=$(openssl rand -base64 32 | tr -d '=+/' | cut -c1-32)
    SESSION_SECRET=$(openssl rand -hex 32)
    APP_PORT=5000
    
    # Get server IP
    SERVER_IP=$(curl -s http://checkip.amazonaws.com 2>/dev/null || echo "localhost")
    
    log "Database: $DB_NAME"
    log "User: $DB_USER"
    log "Port: $APP_PORT"
    log "Server IP: $SERVER_IP"
    
    success "Environment configured"
}

# Install all system dependencies automatically
install_system_deps() {
    header "Installing System Dependencies"
    
    # Update system
    log "Updating system packages..."
    sudo apt update -qq
    sudo apt upgrade -y -qq
    
    # Essential packages
    PACKAGES=(
        curl wget gnupg lsb-release ca-certificates
        postgresql postgresql-contrib postgresql-client
        nginx certbot python3-certbot-nginx
        build-essential git htop unzip
        software-properties-common ufw
        openssl pwgen
    )
    
    log "Installing core packages..."
    sudo apt install -y "${PACKAGES[@]}"
    
    # Node.js 20 LTS (auto-install latest)
    if ! command -v node &>/dev/null || [[ $(node -v | cut -d'.' -f1 | tr -d 'v') -lt 18 ]]; then
        log "Installing Node.js 20 LTS..."
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
        sudo apt install -y nodejs
    fi
    
    # PM2 (auto-install latest)
    if ! command -v pm2 &>/dev/null; then
        log "Installing PM2 process manager..."
        sudo npm install -g pm2@latest
    fi
    
    # Start and enable services
    sudo systemctl enable --now postgresql nginx
    
    # Verify installations
    log "Versions installed:"
    log "  Node.js: $(node -v)"
    log "  NPM: $(npm -v)"
    log "  PostgreSQL: $(psql --version | head -1)"
    log "  PM2: $(pm2 -v)"
    
    success "System dependencies installed"
}

# Automatically setup and configure PostgreSQL
setup_database_auto() {
    header "Automatic Database Setup"
    
    # Ensure PostgreSQL is running
    if ! sudo systemctl is-active --quiet postgresql; then
        log "Starting PostgreSQL..."
        sudo systemctl start postgresql
        sleep 3
    fi
    
    # Configure PostgreSQL for better performance
    log "Optimizing PostgreSQL configuration..."
    sudo tee -a /etc/postgresql/*/main/postgresql.conf >/dev/null << 'PGCONF'

# CryptoHub Optimizations
shared_buffers = 256MB
effective_cache_size = 1GB
maintenance_work_mem = 64MB
checkpoint_completion_target = 0.9
wal_buffers = 16MB
default_statistics_target = 100
random_page_cost = 1.1
effective_io_concurrency = 200
PGCONF
    
    # Restart PostgreSQL with new config
    sudo systemctl restart postgresql
    sleep 3
    
    # Create database and user with full automation
    log "Creating database and user: $DB_USER@$DB_NAME"
    sudo -u postgres psql << DBEOF
-- Drop existing if present
DROP DATABASE IF EXISTS $DB_NAME;
DROP USER IF EXISTS $DB_USER;

-- Create user with all needed privileges
CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD' CREATEDB SUPERUSER;

-- Create database
CREATE DATABASE $DB_NAME OWNER $DB_USER;

-- Grant all privileges
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;

-- Connect to database and setup permissions
\c $DB_NAME

-- Grant schema permissions
GRANT ALL ON SCHEMA public TO $DB_USER;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO $DB_USER;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO $DB_USER;
GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public TO $DB_USER;

-- Set default privileges
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO $DB_USER;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO $DB_USER;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON FUNCTIONS TO $DB_USER;

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Show success
SELECT 'Database setup completed successfully!' AS status;
DBEOF
    
    # Auto-generate DATABASE_URL
    DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME"
    
    # Test database connection
    log "Testing database connection..."
    if psql "$DATABASE_URL" -c "SELECT 'Connection successful!' AS status;" >/dev/null 2>&1; then
        success "Database connection verified"
    else
        error "Database connection failed"
        # Auto-retry with service restart
        warn "Attempting to fix database connection..."
        sudo systemctl restart postgresql
        sleep 5
        if psql "$DATABASE_URL" -c "SELECT version();" >/dev/null 2>&1; then
            success "Database connection restored"
        else
            error "Database setup failed. Check PostgreSQL logs: sudo journalctl -u postgresql"
            exit 1
        fi
    fi
    
    success "Database setup completed"
}

# Setup application automatically
setup_application_auto() {
    header "Application Setup"
    
    # Handle directory setup
    if [ "$INSTALL_MODE" = "fresh" ]; then
        if [ ! -f "package.json" ]; then
            error "package.json not found. Run this script from your CryptoHub project directory."
            exit 1
        fi
        
        log "Creating application directory: $APP_DIR"
        sudo mkdir -p "$APP_DIR"
        sudo chown -R "$USER:$USER" "$APP_DIR"
        
        log "Copying application files..."
        cp -r . "$APP_DIR/"
    fi
    
    cd "$APP_DIR"
    
    # Clean previous builds
    log "Cleaning previous builds..."
    rm -rf dist/ node_modules/.vite .next build/ coverage/ 2>/dev/null || true
    
    # Auto-generate complete environment configuration
    log "Generating environment configuration..."
    cat > .env << ENVEOF
# Database Configuration - Auto Generated
DATABASE_URL=$DATABASE_URL
PGHOST=localhost
PGPORT=5432
PGUSER=$DB_USER
PGPASSWORD=$DB_PASSWORD
PGDATABASE=$DB_NAME

# Application Configuration
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=$APP_PORT

# Server Configuration
HOST=0.0.0.0
SERVER_IP=$SERVER_IP

# Replit Compatibility
REPL_ID=cryptohub-production
REPLIT_DOMAINS=$SERVER_IP,localhost
REPLIT_DB_URL=$DATABASE_URL

# Security
BCRYPT_ROUNDS=12
JWT_EXPIRE=7d

# File Upload
MAX_FILE_SIZE=50MB
UPLOAD_DIR=uploads

# Auto-generated on $(date)
ENVEOF
    
    # Set proper permissions
    chmod 600 .env
    chown "$USER:$USER" .env
    
    # Load environment
    source .env
    
    success "Application configured"
}

# Build application with automatic optimization
build_application_auto() {
    header "Building Application"
    
    # Install dependencies with automatic retry
    log "Installing Node.js dependencies..."
    export npm_config_fund=false
    export npm_config_audit=false
    export npm_config_progress=false
    
    # Retry logic for npm install
    for i in {1..3}; do
        if npm install --production=false; then
            break
        else
            warn "npm install failed, attempt $i/3"
            if [ $i -eq 3 ]; then
                error "npm install failed after 3 attempts"
                exit 1
            fi
            sleep 5
        fi
    done
    
    # Setup database schema automatically
    log "Initializing database schema..."
    if ! npm run db:push; then
        error "Database schema setup failed"
        # Auto-retry once
        warn "Retrying database schema setup..."
        sleep 3
        if ! npm run db:push; then
            error "Database schema setup failed on retry"
            exit 1
        fi
    fi
    
    # Build with automatic memory management
    log "Building application with optimization..."
    
    # Detect available memory and set NODE_OPTIONS accordingly
    TOTAL_MEM=$(free -m | awk '/^Mem:/ {print $2}')
    if [ "$TOTAL_MEM" -gt 4096 ]; then
        export NODE_OPTIONS="--max-old-space-size=4096"
        log "Using 4GB memory for build (detected ${TOTAL_MEM}MB)"
    elif [ "$TOTAL_MEM" -gt 2048 ]; then
        export NODE_OPTIONS="--max-old-space-size=2048"
        log "Using 2GB memory for build (detected ${TOTAL_MEM}MB)"
    else
        export NODE_OPTIONS="--max-old-space-size=1024"
        log "Using 1GB memory for build (detected ${TOTAL_MEM}MB)"
    fi
    
    # Build with timeout and retry
    if ! timeout 1200 npm run build; then
        warn "Build timeout, retrying with reduced memory..."
        export NODE_OPTIONS="--max-old-space-size=1024"
        if ! timeout 600 npm run build; then
            error "Build failed. Try building locally and uploading dist/ folder."
            exit 1
        fi
    fi
    
    # Verify build output
    if [ ! -f "dist/index.js" ]; then
        error "Build verification failed: dist/index.js not found"
        exit 1
    fi
    
    # Optimize build output
    log "Optimizing build output..."
    find dist/ -name "*.js" -exec gzip -9 -k {} \; 2>/dev/null || true
    
    success "Application built successfully"
}

# Setup PM2 with automatic process management
setup_pm2_auto() {
    header "Process Management Setup"
    
    # Create logs directory
    mkdir -p logs uploads temp
    
    # Stop any existing processes
    pm2 delete all 2>/dev/null || true
    pm2 kill 2>/dev/null || true
    
    # Auto-generate PM2 ecosystem configuration
    log "Creating PM2 configuration..."
    cat > ecosystem.config.js << PMEOF
module.exports = {
  apps: [{
    name: 'cryptohub',
    script: 'dist/index.js',
    cwd: '$APP_DIR',
    instances: 1,
    exec_mode: 'fork',
    
    // Environment variables
    env: {
      NODE_ENV: 'production',
      PORT: $APP_PORT,
      DATABASE_URL: '$DATABASE_URL',
      SESSION_SECRET: '$SESSION_SECRET',
      PGHOST: 'localhost',
      PGPORT: '5432',
      PGUSER: '$DB_USER',
      PGPASSWORD: '$DB_PASSWORD',
      PGDATABASE: '$DB_NAME',
      REPL_ID: 'cryptohub-production',
      REPLIT_DOMAINS: '$SERVER_IP,localhost',
      HOST: '0.0.0.0'
    },
    
    // Logging
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true,
    
    // Resource management
    max_memory_restart: '1G',
    node_args: '--max-old-space-size=1024',
    
    // Auto-restart configuration
    autorestart: true,
    max_restarts: 15,
    min_uptime: '5s',
    restart_delay: 3000,
    
    // Process monitoring
    kill_timeout: 5000,
    wait_ready: true,
    listen_timeout: 10000,
    
    // Health monitoring
    health_check_grace_period: 3000,
    health_check_fatal_exceptions: false,
    
    // Log rotation
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    merge_logs: true,
    
    // Auto-scaling (if needed)
    watch: false,
    ignore_watch: ['node_modules', 'logs', 'uploads']
  }]
};
PMEOF
    
    # Start application with PM2
    log "Starting CryptoHub application..."
    pm2 start ecosystem.config.js
    pm2 save
    
    # Setup auto-startup
    log "Configuring auto-startup..."
    STARTUP_CMD=$(pm2 startup systemd -u "$USER" --hp "$HOME" 2>&1 | grep "sudo env" || true)
    if [ -n "$STARTUP_CMD" ]; then
        eval "$STARTUP_CMD" || warn "PM2 startup configuration had issues"
    fi
    
    success "Process management configured"
}

# Setup Nginx with automatic SSL-ready configuration
setup_nginx_auto() {
    header "Web Server Configuration"
    
    # Create optimized Nginx configuration
    log "Creating Nginx configuration..."
    sudo tee /etc/nginx/sites-available/cryptohub >/dev/null << NGINXEOF
# CryptoHub Nginx Configuration - Auto Generated
server {
    listen 80;
    listen [::]:80;
    server_name _ $SERVER_IP;
    
    # Performance settings
    client_max_body_size 50M;
    client_body_timeout 60s;
    client_header_timeout 60s;
    keepalive_timeout 65;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "camera=(), microphone=(), geolocation=()" always;
    
    # Content Security Policy
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self' https: wss: ws:; frame-src 'self';" always;
    
    # Compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/javascript
        application/xml+rss
        application/json
        image/svg+xml
        application/wasm;
    
    # Rate limiting
    limit_req_zone \$binary_remote_addr zone=api:10m rate=100r/m;
    limit_req_zone \$binary_remote_addr zone=login:10m rate=5r/m;
    
    # Static files with aggressive caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot|webp|map)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        add_header Vary "Accept-Encoding";
        try_files \$uri @proxy;
        
        # Serve pre-compressed files
        location ~* \.(js|css)$ {
            gzip_static on;
        }
    }
    
    # API endpoints with rate limiting
    location /api/auth/login {
        limit_req zone=login burst=3 nodelay;
        proxy_pass http://127.0.0.1:$APP_PORT;
        include /etc/nginx/proxy_params;
    }
    
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://127.0.0.1:$APP_PORT;
        include /etc/nginx/proxy_params;
    }
    
    # WebSocket support
    location /ws/ {
        proxy_pass http://127.0.0.1:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 86400;
    }
    
    # Main application
    location / {
        proxy_pass http://127.0.0.1:$APP_PORT;
        include /etc/nginx/proxy_params;
    }
    
    # Fallback for static files
    location @proxy {
        proxy_pass http://127.0.0.1:$APP_PORT;
        include /etc/nginx/proxy_params;
    }
    
    # Health check
    location /health {
        access_log off;
        return 200 "healthy\\n";
        add_header Content-Type text/plain;
    }
    
    # Block common attacks
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
    
    location ~* \.(env|log|ini)$ {
        deny all;
        access_log off;
        log_not_found off;
    }
}
NGINXEOF
    
    # Create proxy_params if not exists
    if [ ! -f /etc/nginx/proxy_params ]; then
        sudo tee /etc/nginx/proxy_params >/dev/null << 'PROXYEOF'
proxy_set_header Host $http_host;
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto $scheme;
proxy_connect_timeout 60s;
proxy_send_timeout 60s;
proxy_read_timeout 60s;
proxy_buffering on;
proxy_buffer_size 8k;
proxy_buffers 8 8k;
proxy_busy_buffers_size 16k;
PROXYEOF
    fi
    
    # Enable site and disable default
    sudo ln -sf /etc/nginx/sites-available/cryptohub /etc/nginx/sites-enabled/
    sudo rm -f /etc/nginx/sites-enabled/default
    
    # Test and reload Nginx
    if ! sudo nginx -t; then
        error "Nginx configuration test failed"
        exit 1
    fi
    
    sudo systemctl reload nginx
    
    success "Web server configured"
}

# Automatic security hardening
setup_security_auto() {
    header "Security Configuration"
    
    # Firewall setup
    log "Configuring firewall..."
    sudo ufw --force reset >/dev/null 2>&1
    sudo ufw default deny incoming >/dev/null 2>&1
    sudo ufw default allow outgoing >/dev/null 2>&1
    sudo ufw allow ssh >/dev/null 2>&1
    sudo ufw allow 80/tcp >/dev/null 2>&1
    sudo ufw allow 443/tcp >/dev/null 2>&1
    sudo ufw --force enable >/dev/null 2>&1
    
    # PostgreSQL security
    log "Securing PostgreSQL..."
    sudo -u postgres psql << SECEOF >/dev/null 2>&1
-- Change default postgres password
ALTER USER postgres PASSWORD '$(openssl rand -base64 32)';

-- Remove test databases
DROP DATABASE IF EXISTS test;
DROP DATABASE IF EXISTS template0;

-- Update pg_hba.conf for better security
SECEOF
    
    # File permissions
    log "Setting file permissions..."
    chmod 700 "$APP_DIR"
    chmod 600 "$APP_DIR/.env"
    chmod -R 755 "$APP_DIR/dist" 2>/dev/null || true
    chmod -R 755 "$APP_DIR/uploads" 2>/dev/null || true
    
    # Log rotation
    log "Setting up log rotation..."
    sudo tee /etc/logrotate.d/cryptohub >/dev/null << 'LOGEOF'
/var/www/cryptohub/logs/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 644 runner runner
    postrotate
        pm2 reloadLogs
    endscript
}
LOGEOF
    
    success "Security configured"
}

# Automatic verification and health checks
verify_deployment_auto() {
    header "Deployment Verification"
    
    # Wait for application startup
    log "Waiting for application to start..."
    sleep 10
    
    # Check PM2 status
    if ! pm2 list | grep -q "cryptohub.*online"; then
        error "Application not running in PM2"
        warn "Checking PM2 logs..."
        pm2 logs cryptohub --lines 20
        
        # Auto-restart attempt
        warn "Attempting automatic restart..."
        pm2 restart cryptohub
        sleep 5
        
        if ! pm2 list | grep -q "cryptohub.*online"; then
            error "Application startup failed"
            exit 1
        fi
    fi
    
    # Health checks with automatic retry
    log "Running health checks..."
    
    local checks=("database" "http" "nginx" "ssl_ready")
    
    for check in "${checks[@]}"; do
        case $check in
            database)
                if psql "$DATABASE_URL" -c "SELECT 'OK' AS status;" >/dev/null 2>&1; then
                    success "Database: OK"
                else
                    warn "Database: Failed"
                fi
                ;;
            http)
                for i in {1..5}; do
                    if curl -f -s http://localhost:$APP_PORT >/dev/null 2>&1; then
                        success "HTTP: OK"
                        break
                    elif [ $i -eq 5 ]; then
                        warn "HTTP: Not responding"
                    else
                        sleep 2
                    fi
                done
                ;;
            nginx)
                if sudo nginx -t >/dev/null 2>&1; then
                    success "Nginx: OK"
                else
                    warn "Nginx: Configuration issues"
                fi
                ;;
            ssl_ready)
                if [ -f /etc/nginx/sites-available/cryptohub ]; then
                    success "SSL Ready: OK"
                else
                    warn "SSL Ready: Configuration missing"
                fi
                ;;
        esac
    done
    
    success "Verification completed"
}

# Auto-populate database with initial data
populate_database_auto() {
    header "Database Population"
    
    log "Adding initial data..."
    psql "$DATABASE_URL" << 'INITEOF'
-- Site settings
INSERT INTO site_settings (key, value) VALUES 
('site_name', 'CryptoHub'),
('description', 'Ultimate crypto community platform for testnets, airdrops, and Web3 opportunities'),
('twitter_url', 'https://twitter.com/cryptohub'),
('telegram_url', 'https://t.me/cryptohub'),
('discord_url', 'https://discord.gg/cryptohub'),
('github_url', 'https://github.com/cryptohub'),
('linkedin_url', 'https://linkedin.com/company/cryptohub')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

-- Welcome announcement
INSERT INTO announcements (title, content, type, is_active, created_at, updated_at) VALUES 
('🎉 Welcome to CryptoHub!', 'Welcome to the ultimate crypto community platform! Discover testnets, airdrops, and Web3 opportunities. Connect with fellow crypto enthusiasts and stay ahead of the curve.', 'info', true, NOW(), NOW()),
('🚀 Platform Features', 'Explore our comprehensive features: testnet guides, airdrop opportunities, community discussions, and Web3 insights. Join thousands of crypto enthusiasts!', 'success', true, NOW(), NOW())
ON CONFLICT DO NOTHING;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_posts_category ON posts(category);
CREATE INDEX IF NOT EXISTS idx_posts_user_id ON posts(user_id);
CREATE INDEX IF NOT EXISTS idx_comments_post_id ON comments(post_id);
CREATE INDEX IF NOT EXISTS idx_likes_post_id ON likes(post_id);
CREATE INDEX IF NOT EXISTS idx_likes_user_id ON likes(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);

-- Display success message
SELECT 'Database populated successfully!' AS status;
INITEOF
    
    success "Database populated with initial data"
}

# Create comprehensive management tools
create_management_auto() {
    header "Management Tools Creation"
    
    # Main management script
    log "Creating management interface..."
    cat > manage.sh << 'MGMTEOF'
#!/bin/bash
# CryptoHub Automated Management Interface

APP_DIR="/var/www/cryptohub"
cd "$APP_DIR" 2>/dev/null || { echo "❌ CryptoHub not found at $APP_DIR"; exit 1; }

# Load environment
source .env 2>/dev/null || { echo "❌ Environment file not found"; exit 1; }

case "$1" in
    start)
        pm2 start ecosystem.config.js
        echo "✅ CryptoHub started"
        ;;
    stop)
        pm2 stop cryptohub
        echo "✅ CryptoHub stopped"
        ;;
    restart)
        pm2 restart cryptohub
        echo "✅ CryptoHub restarted"
        ;;
    reload)
        pm2 reload cryptohub
        echo "✅ CryptoHub reloaded (zero-downtime)"
        ;;
    status)
        echo "📊 CryptoHub Status:"
        pm2 status cryptohub
        echo ""
        echo "🌐 URLs:"
        echo "  Local: http://localhost:$PORT"
        echo "  Public: http://$(curl -s http://checkip.amazonaws.com 2>/dev/null)"
        ;;
    logs)
        pm2 logs cryptohub "${2:---lines=50}"
        ;;
    monitor)
        pm2 monit
        ;;
    ssl)
        [[ -z "$2" ]] && { echo "Usage: $0 ssl domain.com"; exit 1; }
        echo "🔒 Setting up SSL for $2..."
        sudo sed -i "s/server_name .*;/server_name $2;/" /etc/nginx/sites-available/cryptohub
        sudo nginx -t && sudo systemctl reload nginx
        sudo certbot --nginx -d "$2" --non-interactive --agree-tos --email "admin@$2" --redirect
        echo "✅ SSL configured for $2"
        ;;
    backup)
        BACKUP_DIR="/var/backups/cryptohub"
        sudo mkdir -p "$BACKUP_DIR"
        BACKUP_FILE="$BACKUP_DIR/backup-$(date +%Y%m%d-%H%M%S).sql"
        echo "💾 Creating backup..."
        pg_dump "$DATABASE_URL" > "$BACKUP_FILE"
        echo "✅ Backup created: $BACKUP_FILE"
        ;;
    restore)
        [[ -z "$2" ]] && { echo "Usage: $0 restore backup-file.sql"; exit 1; }
        echo "🔄 Restoring from $2..."
        psql "$DATABASE_URL" < "$2"
        echo "✅ Database restored"
        ;;
    update)
        echo "🔄 Updating CryptoHub..."
        git pull
        npm install
        npm run build
        pm2 restart cryptohub
        echo "✅ Update completed"
        ;;
    health)
        echo "🏥 === CryptoHub Health Check ==="
        
        # PM2 Status
        echo -n "PM2: "
        pm2 list | grep -q "cryptohub.*online" && echo "✅ Online" || echo "❌ Offline"
        
        # Database
        echo -n "Database: "
        psql "$DATABASE_URL" -c "SELECT 1;" >/dev/null 2>&1 && echo "✅ Connected" || echo "❌ Error"
        
        # HTTP
        echo -n "HTTP: "
        curl -f -s http://localhost:$PORT >/dev/null 2>&1 && echo "✅ Responding" || echo "❌ No response"
        
        # Nginx
        echo -n "Nginx: "
        sudo nginx -t >/dev/null 2>&1 && echo "✅ OK" || echo "❌ Config error"
        
        # SSL
        echo -n "SSL: "
        [ -f /etc/letsencrypt/live/*/fullchain.pem ] && echo "✅ Configured" || echo "⚠️  Not configured"
        
        echo ""
        echo "📈 System Resources:"
        df -h / | tail -1 | awk '{print "💾 Disk: " $3 "/" $2 " (" $5 " used)"}'
        free -h | awk '/^Mem:/ {print "🧠 Memory: " $3 "/" $2 " (" int($3/$2*100) "% used)"}'
        echo "⚡ Load: $(uptime | awk -F'load average:' '{print $2}')"
        ;;
    clean)
        echo "🧹 Cleaning up..."
        pm2 flush cryptohub
        sudo rm -rf logs/*.log
        sudo rm -rf uploads/temp/*
        echo "✅ Cleanup completed"
        ;;
    *)
        echo "🎛️  CryptoHub Management Commands:"
        echo ""
        echo "  Application Control:"
        echo "    $0 start           - Start application"
        echo "    $0 stop            - Stop application"
        echo "    $0 restart         - Restart application"
        echo "    $0 reload          - Zero-downtime reload"
        echo "    $0 status          - Show detailed status"
        echo ""
        echo "  Monitoring:"
        echo "    $0 logs [lines]    - Show application logs"
        echo "    $0 monitor         - Real-time monitoring"
        echo "    $0 health          - Complete health check"
        echo ""
        echo "  Maintenance:"
        echo "    $0 ssl domain      - Setup SSL certificate"
        echo "    $0 backup          - Create database backup"
        echo "    $0 restore file    - Restore database"
        echo "    $0 update          - Update from git"
        echo "    $0 clean           - Clean logs and temp files"
        echo ""
        exit 1
        ;;
esac
MGMTEOF
    
    chmod +x manage.sh
    
    # Create systemd service for reliability
    log "Creating systemd service..."
    sudo tee /etc/systemd/system/cryptohub.service >/dev/null << SYSTEMDEOF
[Unit]
Description=CryptoHub Application
After=network.target postgresql.service nginx.service
Wants=postgresql.service nginx.service

[Service]
Type=forking
User=$USER
WorkingDirectory=$APP_DIR
Environment=NODE_ENV=production
ExecStart=/usr/bin/pm2 start ecosystem.config.js --no-daemon
ExecReload=/usr/bin/pm2 reload ecosystem.config.js
ExecStop=/usr/bin/pm2 stop ecosystem.config.js
Restart=always
RestartSec=10
KillMode=mixed
TimeoutStopSec=30

[Install]
WantedBy=multi-user.target
SYSTEMDEOF
    
    sudo systemctl daemon-reload
    sudo systemctl enable cryptohub >/dev/null 2>&1 || warn "systemd service registration had issues"
    
    success "Management tools created"
}

# Main execution flow
main() {
    # Run all setup functions in sequence
    setup_environment
    install_system_deps
    setup_database_auto
    setup_application_auto
    build_application_auto
    setup_pm2_auto
    setup_nginx_auto
    setup_security_auto
    verify_deployment_auto
    populate_database_auto
    create_management_auto
    
    # Final success report
    echo ""
    echo "🎉 =================================================="
    echo "🎉      CryptoHub Deployment Successful!          "
    echo "🎉 =================================================="
    echo ""
    echo "🌐 Access Your Application:"
    echo "   👉 Local: http://localhost:$APP_PORT"
    echo "   👉 Public: http://$SERVER_IP"
    echo ""
    echo "🔧 Management Commands:"
    echo "   ./manage.sh status     - Check application status"
    echo "   ./manage.sh logs       - View application logs"
    echo "   ./manage.sh health     - Complete health check"
    echo "   ./manage.sh ssl domain.com - Setup SSL certificate"
    echo "   ./manage.sh monitor    - Real-time monitoring"
    echo ""
    echo "📊 Database Information:"
    echo "   Database: $DB_NAME"
    echo "   User: $DB_USER"
    echo "   Host: localhost:5432"
    echo ""
    echo "📁 Important Locations:"
    echo "   Application: $APP_DIR"
    echo "   Logs: $APP_DIR/logs/"
    echo "   Config: $APP_DIR/.env"
    echo "   Uploads: $APP_DIR/uploads/"
    echo ""
    echo "🚀 Next Steps:"
    echo "   1. Visit your application URL"
    echo "   2. Sign up (first user becomes admin)"
    echo "   3. Configure site settings in admin panel"
    echo "   4. Setup SSL: ./manage.sh ssl yourdomain.com"
    echo "   5. Monitor: ./manage.sh monitor"
    echo ""
    echo "✅ Your CryptoHub platform is ready for production!"
    echo ""
}

# Execute main function with all arguments
main "$@"